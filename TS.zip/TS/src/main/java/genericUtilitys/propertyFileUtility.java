package genericUtilitys;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class propertyFileUtility {
	/**
	 * This method will read the data from propertyFile.
	 * @throws IOException 
	 */
public String readDataFromPropertyFile(String key) throws IOException {
	FileInputStream fis=new FileInputStream("./userCretentials.properties");
	Properties p=new Properties();
	p.load(fis);
	String value=p.getProperty(key);
	return value;
}
}