package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;
	
   //Decleration

	@FindBy(id="details-button")
	WebElement privacy;

	@FindBy(id="proceed-link")
	WebElement link;

	@FindBy(xpath = "//input[@placeholder='Enter username']")
	WebElement usernameEdt;

	@FindBy(xpath = "//input[@placeholder='ENTER PASSWORD']")
	WebElement passwordEdt;

	@FindBy(xpath = "//button[text()=' Sign In ']")
	WebElement signinBtn;

	@FindBy(xpath = "//input[@placeholder='ENTER OTP']")
	WebElement otpEdt;

	@FindBy(xpath = "(//button[text()=' Submit '])[1]")
	WebElement submitBtn;

   //	Initilization

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
    // provide getters method to acces elements

	public WebElement getPrivacy() {
		return privacy;
	}

	public WebElement getLink() {
		return link;
	}

	public WebElement getUsernameEdt() {
		return usernameEdt;
	}

	public WebElement getPasswordEdt() {
		return passwordEdt;
	}

	public WebElement getSigninBtn() {
		return signinBtn;
	}

	public WebElement getOtpEdt() {
		return otpEdt;
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public void rbiLogin(String username, String password, String otp) {
		privacy.click();
		link.click();
		usernameEdt.sendKeys(username);
		passwordEdt.sendKeys(password);
		signinBtn.click();
		otpEdt.sendKeys(otp);
		submitBtn.click();
	}
//	public void goTo() {
//		driver.get("https://10.20.39.98:7001/retail/tokenrbi/dashboard/ui/login");
//	}
}
