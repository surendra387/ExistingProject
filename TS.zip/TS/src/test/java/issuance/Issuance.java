package issuance;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import objectRepository.LoginPage;

public class Issuance {
	@Test(invocationCount = 2)
	public void create_issuance() throws InterruptedException {
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver = new ChromeDriver(options);
        WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver.get("https://10.25.1.2/rcbdc-go/retail/tokensbi/dashboard/ui//login");

//	driver.findElement(By.xpath("//button[@id='details-button']")).click();
//	driver.findElement(By.xpath("//a[text()='Proceed to 10.20.39.98 (unsafe)']")).click();
//	driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("NPCIUSER");
//	driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Password@123");
//	driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
//	driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
//	driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();

		LoginPage lp = new LoginPage(driver);
		lp.getPrivacy().click();
		lp.getLink().click();
		lp.getUsernameEdt().sendKeys("TSPADMIN");
		lp.getPasswordEdt().sendKeys("Password@123");
		lp.getSigninBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubmitBtn().click();
//	Thread.sleep(5000);
//	driver.findElement(By.xpath("//div[@class='c-avatar c-avatar--xsmall dropdown-toggle']")).click();
//	driver.findElement(By.xpath("//a[text()='Log out']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[text()='Issuance']")).click();
		driver.findElement(By.xpath("//button[text()=' Request Issuance ']")).click();
		WebElement element = driver.findElement(By.xpath("//select[@formcontrolname='denomination']"));
		Select s = new Select(element);
		s.selectByVisibleText("50");
		driver.findElement(By.xpath("//input[@type='number']")).sendKeys("1000");
		driver.findElement(By.xpath("(//button[@type='submit'])[4]")).click();
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//b[text()='SUBMIT']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).click();
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		driver.findElement(By.xpath("//button[@id='yes-button']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[@class='c-avatar c-avatar--xsmall dropdown-toggle']")).click();
		driver.findElement(By.xpath("//a[text()='Log out']")).click();
		Thread.sleep(2000);
		Navigation n = driver.navigate();
		n.refresh();

		driver.get("https://10.25.1.2/rcbdc-go/retail/tokenrbi/dashboard/ui/login");

		driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("TESTER");
		driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Abcd@123");
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();

//	lp.getUsernameEdt().sendKeys("RBIADMIN");
//	lp.getPasswordEdt().sendKeys("Password@123");
//	lp.getSigninBtn().click();
//	lp.getOtpEdt().sendKeys("999999");
//	lp.getSubmitBtn().click();
//	
		driver.findElement(By.xpath("//span[text()='Issuance']")).click();
		driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).click();
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		driver.findElement(By.xpath("//b[text()='Yes']")).click();
//		Navigation n = driver.navigate();
		Thread.sleep(3000);
		n.refresh();
		Thread.sleep(2000);
		n.refresh();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='c-avatar c-avatar--xsmall dropdown-toggle']")).click();
		driver.findElement(By.xpath("//a[text()='Log out']")).click();
		n.refresh();
		Thread.sleep(5000);
		n.refresh();
		
	}
}
