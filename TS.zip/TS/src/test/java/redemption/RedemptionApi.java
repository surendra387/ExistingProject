package redemption;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RedemptionApi {
	@Test(priority = 1)
	public void redeem() {

	File Body=new File("/home/pasala.surendra_oli@npci.org.in/Desktop/vajra_Platform_Go_Apis/TS/tokens");
		Response res = given().contentType(ContentType.XML).body(Body)
.when().post("https://10.20.39.98:7001/retail/tokennipl/dashboard/api/token/RespUpdateToken/2.0/urn:txnid::{{retailTransferID}}");
					
	}
}
