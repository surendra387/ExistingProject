package redemption;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class BankRedeem {
	@Test(priority = 1)
	public void create_issuance() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://10.20.39.98:7001/retail/tokennipl/dashboard/ui/login");
		driver.findElement(By.xpath("//button[@id='details-button']")).click();
		driver.findElement(By.xpath("//a[text()='Proceed to 10.20.39.98 (unsafe)']")).click();

		driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("TSPADMIN");
		driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Password@123");
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
		driver.findElement(By.xpath("//span[text()='Redemption']")).click();
		driver.findElement(By.xpath("//button[text()=' Request Redeem ']")).click();
		WebElement element = driver.findElement(By.xpath("//select[@formcontrolname='denomination']"));
		Select s = new Select(element);
		s.selectByValue("1");
		driver.findElement(By.xpath("//input[@type='number']")).sendKeys("10");
		driver.findElement(By.xpath("(//button[@type='submit'])[4]")).click();
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//b[text()='SUBMIT']")).click();
		Thread.sleep(6000);
		driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).click();
//        String msg=	driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).getText();
//		System.out.println(msg);
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("68.5test");
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		driver.findElement(By.xpath("//button[@id='yes-button']")).click();
		
	}
}
