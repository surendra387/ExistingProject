package testing;

public class tes {
	
String  name,colour;
public tes(String name,String colour)
{
	this.name=name;
    this.colour=colour;
}
public static void main(String[] args) {
	tes t=new tes("red","puppy");
	System.out.println(t.colour);
	System.out.println(t.name);
}
}
