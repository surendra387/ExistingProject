package testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class INDENT {
@Test
public void indent() {
	WebDriver driver=new ChromeDriver();
	driver.get("https://10.25.1.2/retail/tokenrbi/dashboard/ui/login");
}
}
