package Indent;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import objectRepository.LoginPage;

public class Create_Indent2 {
@Test()
public void createIndent() throws InterruptedException {
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	ChromeDriver driver = new ChromeDriver(options);

	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://10.20.39.98:7001/retail/tokenrbi/dashboard/ui/login");
//	driver.findElement(By.xpath("//button[@id='details-button']")).click();
//	driver.findElement(By.xpath("//a[text()='Proceed to 10.20.39.98 (unsafe)']")).click();
//	
//	driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("RBIADMIN");
//	driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Password@123");
//	driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
//	driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
//	
//	driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
	
	LoginPage lg=new LoginPage(driver);
//	lg.goTo();
	lg.rbiLogin("RBIADMIN","Password@123", "999999");
//	for(int i=0;i<=2;i++)   
//	{
	driver.findElement(By.xpath("//span[text()='Creation']")).click();
	driver.findElement(By.xpath("//button[text()=' Create Indent ']")).click();
	WebElement element = driver.findElement(By.xpath("//select[@formcontrolname='denomination']"));
    Select s=new Select(element);
	s.selectByIndex(5);
	driver.findElement(By.xpath("//input[@type='number']")).sendKeys("10");
	driver.findElement(By.xpath("(//button[@type='submit'])[4]")).click();
	driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
	driver.findElement(By.xpath("//b[text()='SUBMIT']")).click();
	Thread.sleep(3000);
    driver.findElement(By.xpath("//span[@aria-hidden='true']")).click();
    Thread.sleep(3000);
	driver.findElement(By.xpath("//span[text()='Creation']")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//a[text()='Submissions']")).click();
	Thread.sleep(3000);
//	driver.findElement(By.xpath("(//td[@class='c-table__cell'])[1]")).click();
	driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//textarea[@placeholder='Remarks upto 500 characters']")).sendKeys("test");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
	driver.findElement(By.xpath("//button[@id='yes-button']")).click();
	Thread.sleep(2000);
	Navigation nav = driver.navigate();
	nav.refresh();
	Thread.sleep(2000);
	nav.refresh();

	}
}
//}


