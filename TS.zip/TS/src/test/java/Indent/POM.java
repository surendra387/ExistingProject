package Indent;

public class POM {

}
