package practice;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import genericUtilitys.JavaUtility;
import genericUtilitys.propertyFileUtility;

public class Demo {
	@Test(invocationCount =10 )
	public void test() throws IOException, InterruptedException {
		
	JavaUtility jUtil=new JavaUtility();
//	propertyFileUtility pUtil=new propertyFileUtility();
//	System.out.println(jUtil.getRandomNumber());
//	System.out.println(jUtil.getDate());
//	System.out.println(jUtil.getFormatedSystemDate());
//	System.out.println(jUtil.sequen());

	String body="<?xml version=\"1.0\" encoding=\"UTF-8\"?> <ns2:ReqUpdateToken xmlns:ns2=\"http://npci.org/token/schema/\"> <Head msgId=\"TestTransferOCT04-"+jUtil.sequen()+"\"+ orgId=\"678910\" ts=\"2022-12-26T17:25:17+05:30\" ver=\"2.0\"/> <ReqDetails type=\"TRANSFER\"> <Amount curr=\"INR\" value=\"500.00\"> <Denominations> <Denomination count=\"1\" value=\"500.00\"/> </Denominations> </Amount> <Tokens> <Token> <Detail name=\"tokenId\" value=\"00174c05bd50c429676e1f26982175498f9a1af868424da495abe37a9ecf4c3a\"/> <Detail name=\"type\" value=\"RETAIL\"/> <Detail name=\"serialNumber\" value=\"000000000000738\"/> <Detail name=\"value\" value=\"500.00\"/> <Detail name=\"currency\" value=\"INR\"/> <Detail name=\"creationTimeStamp\" value=\"2022-12-01T04:07:37.260Z\"/> <Detail name=\"issuerAddress\" value=\"0x5a4da8462e47584094f57ab37acc5ad229d77ffe\"/> <Detail name=\"issuerSign\" value=\"0x2906ef62f7d15167403a921601f4e1d6d14ce213ec049a4f1d99f2c66fe665ff0c2e4356bb41ba8f9959d8a902b12fa818ba74ac422ac0f5add3339683a8046a1b\"/> </Token> </Tokens> <DeviceInfo> <Tag name=\"MOBILE\" value=\"910000000000\"/> </DeviceInfo> <Details> <Detail name=\"senderOrgId\" value=\"678910\"/> <Detail name=\"senderOrgWalletAddress\"/> <Detail name=\"receiverOrgId\" value=\"123456\"/> <Detail name=\"receiverOrgWalletAddress\"/> <Detail name=\"transactionId\" value=\"TestTransferOCT04-"+jUtil.sequen()+"/> </Details> </ReqDetails> <Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"> <SignedInfo> <CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/> <SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#rsa-sha256\"/> <Reference URI=\"\"> <Transforms> <Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/> </Transforms> <DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"/> <DigestValue>Ytm13wLjhLZ5hvkhyHJlcSJD8Cy1IVBRY/b1WlMYbUE=</DigestValue> </Reference> </SignedInfo> <SignatureValue>lITemlcIVwMmTNuFVjMCSPmvZeI4/mxeoAst4XvThce/Lo/vVclX5cXPz/BrA5btBasvfG3wZ8Cj&#13;xnZS1msLKPxeOr4r/TKAxg+xpPgcm+7/rz6vaEWK4g9DAU3qGQmeDuSFQi/+h/acYy3VCjaKdceL&#13;V4EQ8RGLqnPb/ReY74snyfxxqsLAvIgrwtXyBA0pplsadBTcUv5A4Pr9da0vNxXAaPBbeh5yIYor&#13;ubEbo8S60hHJ3hutUIjKrJom455xf+/E3BAXXRDPMfnk/2836bKprKEXgW5+rssqXp3ztIi+ZLj6&#13;nYhajsESUgm0rBqpSA8VHrpKbwieh1ikRrmV9A==</SignatureValue> </Signature> </ns2:ReqUpdateToken>\n"
			+" " ;
	System.out.println(body);
//	System.out.println(pUtil.readDataFromPropertyFile("browser"));
////		propertyFileUtility pUtil = new propertyFileUtility();
//		String BROWSER = pUtil.readDataFromPropertyFile("browser");
//		String USERNAME = pUtil.readDataFromPropertyFile("username");
//		String PASSWORD = pUtil.readDataFromPropertyFile("password");
//		
//		System.out.println(PASSWORD);
		
		
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver = new ChromeDriver(options);
//		WebDriver driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://www.flipkart.com/");
//		Thread.sleep(2000);
//		driver.findElement(By.className("H6-NpN _3N4_BX")).click();
		
	}
}
