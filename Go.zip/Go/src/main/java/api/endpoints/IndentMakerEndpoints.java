package api.endpoints;
import static io.restassured.RestAssured.given;
public class IndentMakerEndpoints implements AuthToken{
public  static void  draftIndent()  {
	given()
	.headers("Authorization", "Bearer "+Auth_Token)
	.contentType("application/json")
//	.body()
	.when();
}
}
