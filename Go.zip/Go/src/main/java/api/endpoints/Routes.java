package api.endpoints;

public class Routes {
	
	public static String rbi_base_url="http://localhost:9002/rrb/api/retail-token-system/v1";
	
	public static String sbi_base_url="http://localhost:9003/rbb-sbi/sbi/api/v1/";
//	http://localhost:9003/rbb-sbi/sbi/api/v1/wallet/
//		http://localhost:9003/rbb-sbi/sbi/api/v1/token/issuance
//	localhost:9002/rrb/api/retail-token-system/v1/wallet/
    //Login
	
	public static String rbi_get_Session=rbi_base_url+"/auth/session";
	
	public static String rbi_login_User=rbi_base_url+"/auth/login";
	
	//IndentMaker

	public static String draft_indent=rbi_base_url+"/indent/";
	
	public static String create_indent=rbi_base_url+"/indent/";
	
	public static String update_draft_indent=rbi_base_url+"/indent/{Id}";
	
	public static String submit_draft_indent=rbi_base_url+"/indent/{Id}";
	
	public static String discard_draft_indent=rbi_base_url+"/indent/{Id}";
	
	//IndentChecker
	public static String approve_indent=rbi_base_url+"/indent/{Id}";
	
	public static String list_indent=rbi_base_url+"/indent/";
	
	public static String indent_By_Id_url=rbi_base_url+"/indent/{Id}";
	
	//wallets
	public static String create_indent_wallet=rbi_base_url+"/wallet";
	
	public static String get_indent_wallet=rbi_base_url+"/wallet";
	
	public static String create_issuance_wallet=sbi_base_url+"/wallet";
	
	public static String get_issuance_wallet=sbi_base_url+"/wallet";
	
	
//Issuance Maker

	public static String draft_issuance=sbi_base_url+"/token/issuance";
	
	public static String create_issuance=sbi_base_url+"/token/issuance";

	public static String submit_draft_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	public static String discard_draft_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	public static String checker_approve_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	public static String rbi_approve_issuance=rbi_base_url+"/token/issuance/{Id}";
}
