package login;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;


import api.endpoints.Routes;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class UserLogin {
	
public static String Id;
public static String enc_N;
public static String enc_K;

	@Test
	public void getSessionTest() {
		Response res = given().when().post(Routes.rbi_get_Session);
		String Body=res.getBody().asString();
		System.out.println(Body);
		
		JsonPath jp=new JsonPath(Body);
		String formatedJson=jp.prettify();
		System.out.println(formatedJson);

		Id = res.jsonPath().getString("data.id");
		enc_N = res.jsonPath().getString("data.enc_n");
		enc_K = res.jsonPath().getString("data.enc_k");

		System.out.println("id :" +Id);
		System.out.println("enc_n :" +enc_N);
		System.out.println(enc_K);
	}

//	@Test
	public void loginUser() {

	}
}
