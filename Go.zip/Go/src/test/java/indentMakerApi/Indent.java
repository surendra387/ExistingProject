package indentMakerApi;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.response.Response;

public class Indent implements AuthToken {

	public static String Data1;
	public static String Data2;

	@Test(priority = 1, enabled = true)
	public void draftIndent() {
		Random random = new Random();
		int count = random.nextInt(50000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);

		double totalAmount = count * selectedDenomination;

		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Draft");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "maker remarks");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", count);
		token.put("denomination", selectedDenomination);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.body(requestBody).when().post(Routes.draft_indent);

		Data1 = res.jsonPath().getString("data");
		System.out.println("DraftIndent id is: " + Data1);
       
		//	validate the response ststus code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 2, enabled = true)
	public void createIndent() {
		Random random = new Random();
		int count = random.nextInt(50000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);
		double totalAmount = count * selectedDenomination;
		System.out.println(totalAmount);
		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "CREATE");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "Creation TEST 123");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", count);
		token.put("denomination", selectedDenomination);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.body(requestBody).when().post(Routes.create_indent);

		Data2 = res.jsonPath().getString("data");
		System.out.println("Create Indent id is :" + Data2);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}

	@Test(priority = 3, enabled = true)
	public void updateIndent() {
		Random random = new Random();
		int count = random.nextInt(50000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);

		double totalAmount = count * selectedDenomination;

		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Draft");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "maker remarks");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", count);
		token.put("denomination", selectedDenomination);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.pathParam("Id", Data1).body(requestBody).when().post(Routes.update_draft_indent);
		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("Update DraftIndent ID is: " + Data1);
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 4, enabled = true)
	public void submitIndent() {

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Create");
		Map<String, Object> indent = new HashMap<>();
		indent.put("makerRemarks", "maker remarks 12");
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.pathParam("Id", Data1).body(requestBody).when().post(Routes.submit_draft_indent);

		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("submit DraftIndent ID is: " + Data1);
		
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}
	@Test(priority = 5, enabled = false)
	public void discardIndent() {

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Discard");
		requestBody.put("checkerRemark", 123);
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.pathParam("Id", Data1).body(requestBody).when().post(Routes.discard_draft_indent);

		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("Discard DraftIndent ID is: " + Data1);
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

}
