package issuanceMakerApi.copy;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.gherkin.model.When;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Issuance implements AuthToken {
	public static String Data1;
	public static String Data2;
	@Test(priority = 1,enabled = true)
	public void draft_Issuance() {

		Random random = new Random();
		int count = random.nextInt(5000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.00, 5.00, 10.00, 20.00, 50.00, 100.00, 200.00, 500.00);
		Double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);

		double totalAmount = count * selectedDenomination;
		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<String, Object>();
		requestBody.put("totalAmount", totalAmount);
		requestBody.put("makerRemarks", "Test Remark");
		requestBody.put("txnRefNo", "TXN-001");
		requestBody.put("status", "DRAFT");
		
		List<Map<String, Object>> tokensRequested = new ArrayList<Map<String, Object>>();
		Map<String, Object> tokens = new HashMap<String, Object>();
		tokens.put("count", count);
		tokens.put("denomination", selectedDenomination);
		tokensRequested.add(tokens);
		requestBody.put("tokensRequested", tokensRequested);
	
		Response res = given().headers("Authorization", "Bearer " + Auth_Token_sbi).body(requestBody).when()
				.post(Routes.draft_issuance);
//		String Body=res.getBody().asString();
//		System.out.println(Body);
		
		 Data1 = res.jsonPath().getString("data");
		System.out.println("Draft Issuance Id is:" + Data1);

        //	validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid Status Code");

        // Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

        // Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
//	@Test(priority = 2,enabled = true)
	public void submit_draft_issuance() {
		System.out.println(Data1);
		Map<String, Object> requestBody=new HashMap<String, Object>();
		requestBody.put("makerRemarks", "maker-remarks-direct");
		requestBody.put("txnRefNo", "");
		requestBody.put("status", "Create");
	Response res = given()
		.headers("Authorization", "Bearer "+Auth_Token_sbi)
		.body(requestBody)
		.pathParam("Id", Data1)
		.when()
		.post(Routes.submit_draft_issuance);
	String Body=res.getBody().asString();
	System.out.println(Body);
	Data1=res.jsonPath().getString("data");
	System.out.println("Submit Issuance Id is:"+Data1);
	
	 //	validate response status code
	int statusCode = res.getStatusCode();
	Assert.assertEquals(statusCode, 200, "Invalid Status Code");

    // Validate the response status line
	String loginStatusLine = res.getStatusLine();
	Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

    // Validate the response content type
	String loginContentType = res.getContentType();
	Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	
	}
	@Test(priority = 3,enabled = true)
	public void discard_draft_issuance() {
		Map<String, Object>requestBody=new HashMap<String, Object>();
		requestBody.put("makerRemarks", "maker-remarks-direct");
		requestBody.put("txnRefNo", "");
		requestBody.put("status", "Discard");
	 Response res=given()
		.headers("Authorization", "Bearer "+Auth_Token_sbi)
		.body(requestBody)
		.pathParam("Id", Data1)
		.when()
		.post(Routes.discard_draft_issuance);
	 
		Data1=res.jsonPath().getString("data");
		System.out.println("Discard Issuance Id is:"+Data1);
		
		 //	validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid Status Code");

	    // Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	    // Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
		
	}
	@Test(priority =4,enabled = true )
	public void create_indent() {
		Random random = new Random();
		int count1 = random.nextInt(5000) + 1;
		System.out.println(count1);
		
		int count2 = random.nextInt(5000) + 1;
		System.out.println(count2);

		List<Double> denominations = List.of(0.5, 1.00, 5.00, 10.00, 20.00, 50.00, 100.00, 200.00, 500.00);
		Double selectedDenomination1 = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination1);
		
		Double selectedDenomination2 = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination2);
		
		double totalAmount = (count1 * selectedDenomination1)+(count2 * selectedDenomination2);
		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<String, Object>();
		requestBody.put("totalAmount", totalAmount);
		requestBody.put("makerRemarks", "Test Remark");
		requestBody.put("txnRefNo", "TXN-001");
		requestBody.put("status", "CREATE");
		
		List<Map<String, Object>> tokensRequested = new ArrayList<Map<String, Object>>();
		Map<String, Object> token1 = new HashMap<String, Object>();
		token1.put("count", count1);
		token1.put("denomination", selectedDenomination1);
		tokensRequested.add(token1);
		Map<String, Object> token2 = new HashMap<String, Object>();
		token2.put("count", count2);
		token2.put("denomination", selectedDenomination2);
		tokensRequested.add(token2);
		requestBody.put("tokensRequested", tokensRequested);
       Response	res=given()
		.headers("Authorization", "Bearer "+Auth_Token_sbi)
		.body(requestBody)
		
		.when()
		.post(Routes.create_issuance);
		 Data2=res.jsonPath().getString("data");
			System.out.println("Create Issuance id is:"+Data2);
			
			 //	validate response status code
			int statusCode = res.getStatusCode();
			Assert.assertEquals(statusCode, 200, "Invalid Status Code");

		    // Validate the response status line
			String loginStatusLine = res.getStatusLine();
			Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		    // Validate the response content type
			String loginContentType = res.getContentType();
			Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	@Test(priority = 5,enabled = true)
	public void checker_approve_issuance() {
		Map<String, Object>requestBody=new HashMap<String, Object>();
		requestBody.put("makerRemarks", "maker-remarks-direct");
		requestBody.put("txnRefNo", "");
		requestBody.put("status", "CHECK_APPROVE");
      Response res=given()
		.headers("Authorization", "Bearer "+Auth_Token_sbi)
		.body(requestBody)
		.pathParam("Id", Data2)
		.when()
		.post(Routes.checker_approve_issuance);

		Data1=res.jsonPath().getString("data");
		System.out.println("CheckerApproveIssuance id is:"+Data2);
		
		 //	validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid Status Code");

	    // Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	    // Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
		
	}
	@Test(priority = 6,enabled = true)
	public void rbi_approver_issuance() {
		Map<String,Object>requestBody=new HashMap<String, Object>();
		requestBody.put("makerRemarks", "regulator-remarks-direct");
		requestBody.put("txnRefNo", "");
		requestBody.put("status", "APPROVE");
		
	 Response res=	  given()
		.headers("Authorization", "Bearer "+Auth_Token)
		.body(requestBody)
		.pathParam("Id", Data2)
		.when()
		.post(Routes.rbi_approve_issuance);
	String Body= res.getBody().asString();
//	System.out.println(Body);
	JsonPath jp=new JsonPath(Body);
	String formatedJson=jp.prettify();
	System.out.println(formatedJson);
	    Data2=res.jsonPath().getString("data");
		System.out.println("rbiapprove issuance id is:"+Data2);
		
		 //	validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid Status Code");

	    // Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	    // Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	
}
