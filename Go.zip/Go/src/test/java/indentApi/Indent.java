package indentApi;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Indent implements AuthToken {

	public static String Data1;
	public static String Data2;

//	@Test(priority = 1, enabled = true)
	public void draftIndent() {
		Random random = new Random();
		int count = random.nextInt(50000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);

		double totalAmount = count * selectedDenomination;

		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Draft");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "maker remarks");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", count);
		token.put("denomination", selectedDenomination);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.body(requestBody).when().post(Routes.draft_indent);
//		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("DraftIndent id is: " + Data1);
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 2, enabled=true )
	public void createIndent() {
		Random random = new Random();
		int count = random.nextInt(50000) + 1;
//		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
//		System.out.println(selectedDenomination);
//		double totalAmount = count * selectedDenomination;
		double totalAmount = 50000 * 500;
		System.out.println(totalAmount);
		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "CREATE");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "Creation TEST 123");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", 50000);
		token.put("denomination", 500);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.body(requestBody).when().post(Routes.create_indent);
//		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data2 = res.jsonPath().getString("data");
		System.out.println("Create Draft Indent id is :" + Data2);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}

//	@Test(priority = 3, enabled = true)
	public void updateIndent() {
		Random random = new Random();
		int count = random.nextInt(50000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);

		double totalAmount = count * selectedDenomination;

		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Draft");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "maker remarks");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", count);
		token.put("denomination", selectedDenomination);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.pathParam("Id", Data1).body(requestBody).when().post(Routes.update_draft_indent);
		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("Update DraftIndent ID is: " + Data1);
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

//	@Test(priority = 4, enabled = false)
	public void submitIndent() {

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Create");
		Map<String, Object> indent = new HashMap<>();
		indent.put("makerRemarks", "maker remarks 12");
		requestBody.put("indent", indent);

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.pathParam("Id", Data1).body(requestBody).when().post(Routes.submit_draft_indent);

		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("submit DraftIndent ID is: " + Data1);
		
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}
//	@Test(priority = 5, enabled = true)
	public void discardIndent() {

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Discard");
		requestBody.put("checkerRemark", 123);
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json")
				.pathParam("Id", Data1).body(requestBody).when().post(Routes.discard_draft_indent);

		String msg = res.jsonPath().getString("message");
//		System.out.println(msg);
		Data1 = res.jsonPath().getString("data");
		System.out.println("Discard DraftIndent ID is: " + Data1);
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

//	@Test(priority = 6, enabled = true)
	public void approveIndent() {
		Map<String, Object> requestBody = new HashMap<String, Object>();
		requestBody.put("status", "APPROVE");
		Map<String, Object> indent = new HashMap<String, Object>();
		indent.put("checkerRemark", "checkerRemark123");
		requestBody.put("indent", indent);
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).body(requestBody).pathParam("Id", Data2)
				.when().post(Routes.approve_indent);
//		String Body = res.getBody().asString();
//		JsonPath jp = new JsonPath(Body);
//		String formatedJson = jp.prettify();
//		System.out.println(formatedJson);
		Data2 = res.jsonPath().getString("data");
		System.out.println("Approved Indent ID is: " + Data2);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}

	

//	@Test(priority = 7,enabled = true)
	public void indentById() {

		Response res = given().headers("Authorization", "Bearer " + Auth_Token).pathParam("Id", Data2).when()
				.get(Routes.indent_By_Id_url);
		String body = res.getBody().asString();
		JsonPath jp = new JsonPath(body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
//	@Test(priority = 8,enabled = true)
	public void listIndent() {
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).queryParam("status", "DRAFT")
				.queryParam("limit", 10).when().get(Routes.list_indent);

		String Body = res.getBody().asString();

		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		String msg = res.jsonPath().getString("message");
		System.out.println(msg);
		System.out.println(formatedJson);

		// validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid status code");
        
		//validate response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Invalid status line");
        
		//validate response content type
		String contentType = res.getContentType();
		Assert.assertEquals(contentType, "application/json", "Invalid content Type");

	}

}
