package indentChecker;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class List_Indent implements AuthToken {
	@Test
	public void listIndent() {
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).queryParam("status", "DRAFT")
				.queryParam("limit", 10).when().get(Routes.list_indent);

		String Body = res.getBody().asString();

		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		String msg = res.jsonPath().getString("message");
		System.out.println(msg);
		System.out.println(formatedJson);

		// validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid status code");
        
		//validate response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Invalid status line");
        
		//validate response content type
		String contentType = res.getContentType();
		Assert.assertEquals(contentType, "application/json", "Invalid content Type");

	}
}
