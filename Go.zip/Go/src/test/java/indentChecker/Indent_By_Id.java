package indentChecker;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import indentApi.Indent;

public class Indent_By_Id implements AuthToken{
	
	@Test
public void indentById() {
		Indent_Maker2  im=new Indent_Maker2();
	System.out.println(im.Data1);
	
	given()
	.headers("Authorization","Bearer "+Auth_Token)
	.pathParam("Id", im.Data1)
	.when()
	.get(Routes.indent_By_Id_url)
//	.get("http://localhost:9002/rrb/api/retail-token-system/v1/indent/2023-0000027")
	.then().log().all();
}
}
