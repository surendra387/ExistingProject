package indentChecker;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.Assert;
import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import io.restassured.response.Response;

public class Indent_Maker2 implements AuthToken {
	public static String Data1;
	@Test(priority = 1)
	public void draftIndent() {

		Random random = new Random();
		int count1 = random.nextInt(10000) + 1;
		int count2 = random.nextInt(10000) + 1;
		System.out.println(count1);
		System.out.println(count2);

		List<Double> denominations1 = List.of(0.5,1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);
		double selectedDenomination1 = denominations1.get(random.nextInt(denominations1.size()));
		System.out.println(selectedDenomination1);
		List<Double> denominations2 = List.of(0.5,1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);
		double selectedDenomination2 = denominations2.get(random.nextInt(denominations2.size()));
		System.out.println(selectedDenomination2);

//		double totalAmount = count * selectedDenomination;
		double totalAmount = (count1 * selectedDenomination1) + (count2 * selectedDenomination2);
		
		System.out.println(totalAmount);

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "Draft");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "maker remarks");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token1 = new HashMap<>();
		token1.put("count", count1);
		token1.put("denomination", selectedDenomination1);
		tokensToCreateList.add(token1);
		Map<String, Object> token2 = new HashMap<>();
		token2.put("count", count2);
		token2.put("denomination", selectedDenomination2);
		tokensToCreateList.add(token2);
		
		
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);
		
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json").body(requestBody)
				.when().post("http://localhost:9002/rrb/api/retail-token-system/v1/indent/");
	 Data1 = res.jsonPath().getString("data");
		System.out.println(Data1);
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");
		
		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");
		
		
		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
		
	
     
	}
	
//	@Test(priority = 2)
	public void createIndent() {
		Random random = new Random();
		int count = random.nextInt(10000) + 1;
		System.out.println(count);

		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0, 200.0);

		double selectedDenomination = denominations.get(random.nextInt(denominations.size()));
		System.out.println(selectedDenomination);
		double totalAmount = count * selectedDenomination;
		System.out.println(totalAmount);
		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("status", "CREATE");
		Map<String, Object> indent = new HashMap<>();
		indent.put("totalAmount", totalAmount);
		indent.put("makerRemarks", "Creation TEST 123");
		indent.put("tokenType", "retail");
		indent.put("maxCount", 0);
		indent.put("expirationTimestamp", "");
		List<Map<String, Object>> tokensToCreateList = new ArrayList<>();
		Map<String, Object> token = new HashMap<>();
		token.put("count", count);
		token.put("denomination", selectedDenomination);
		tokensToCreateList.add(token);
		indent.put("tokensToCreate", tokensToCreateList);
		requestBody.put("indent", indent);

	
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).contentType("application/json").body(requestBody)
				.when().post("http://localhost:9002/rrb/api/retail-token-system/v1/indent/");
		String Data2 = res.jsonPath().getString("message");
		System.out.println(Data2);
		
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");
		
		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");
		
		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	
}
