package indentCheckerApi;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import indentMakerApi.Indent;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class IndentApprove implements AuthToken {
    String Data2;
    String Data1;
    String randomValue;
	@Test(priority = 1, enabled = true)
	public void approveIndent() {
		Map<String, Object> requestBody = new HashMap<String, Object>();
		requestBody.put("status", "APPROVE");
		Map<String, Object> indent = new HashMap<String, Object>();
		indent.put("checkerRemark", "checkerRemark123");
		requestBody.put("indent", indent);
		Random r=new Random();
        String[] id= {Indent.Data2,Indent.Data1};
        int randomIndex = r.nextInt(id.length);
         randomValue = id[randomIndex];
        System.out.println("random value" + randomValue);
	
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).body(requestBody).pathParam("Id",randomValue)
				.when().post(Routes.approve_indent);
		
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);
		
		Data2 = res.jsonPath().getString("data");
		System.out.println("Approved Indent ID is: " + Data2);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}

	

	@Test(priority = 2,enabled = true)
	public void indentById() {
        System.out.println(randomValue);
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).pathParam("Id", randomValue).when()
				.get(Routes.indent_By_Id_url);
		String body = res.getBody().asString();
		JsonPath jp = new JsonPath(body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
//	@Test(priority = 3,enabled = true)
	public void listIndent() {
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).queryParam("status", "DRAFT")
				.queryParam("limit", 10).when().get(Routes.list_indent);

		String Body = res.getBody().asString();

		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		String msg = res.jsonPath().getString("message");
		System.out.println(msg);
		System.out.println(formatedJson);

		// validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid status code");
        
		//validate response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Invalid status line");
        
		//validate response content type
		String contentType = res.getContentType();
		Assert.assertEquals(contentType, "application/json", "Invalid content Type");

	}

}
