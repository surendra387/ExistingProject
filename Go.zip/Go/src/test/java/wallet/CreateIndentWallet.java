package wallet;

import org.testng.annotations.Test;
import org.testng.Assert;
import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

import static io.restassured.config.RedirectConfig.redirectConfig;
public class CreateIndentWallet implements AuthToken {

	@Test(priority = 1)
	public void create_Indent_Wallet() {
		
	Response res = given()
		.headers("Authorization","Bearer "+Auth_Token)
		.when()
		.post("http://localhost:9002/rrb/api/retail-token-system/v1/wallets");
	String Body=res.getBody().asString();
//	System.out.println(Body);
	JsonPath jp=new JsonPath(Body);
	String formatedJson=jp.prettify();
		System.out.println(formatedJson);
		
		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json; charset=utf-8", "Incorrect content type");
		
	}

	@Test(priority = 2)
	public void getIndentWallet() {

		Response res = given().headers("Authorization", "Bearer " + Auth_Token)

				.when().get(Routes.create_indent_wallet);
		
		String WalletId = res.jsonPath().getString("wallet_id");
		String WalletAddress = res.jsonPath().getString("wallet_address");
		String WalletOwnerId = res.jsonPath().getString("wallet_owner_id");
		
		System.out.println("wallet id is :"+WalletId);
		System.out.println("wallet address is :"+WalletAddress);
		System.out.println("wallet owner id is :"+WalletOwnerId);
		
		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json; charset=utf-8", "Incorrect content type");
	}

}