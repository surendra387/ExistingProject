package issuanceCheckerkerApi;

import org.testng.annotations.Test;
import org.testng.Assert;
import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.response.Response;

import issuanceMakerApi.Issuance;

public class Issuance_Checker implements AuthToken {
	
	  public static String Data3;
	 
	@Test(priority = 1,enabled = true)
	public void checker_approve_issuance() {
		
		Map<String, Object>requestBody=new HashMap<String, Object>();
		requestBody.put("makerRemarks", "maker-remarks-direct");
		requestBody.put("txnRefNo", "");
		requestBody.put("status", "CHECK_APPROVE");
		
		Random r=new Random();
		String[]id= {Issuance.Data1,Issuance.Data2};
	    int IndexValue=r.nextInt(id.length);
	    String randomValue=id[IndexValue];
		System.out.println(randomValue);
         Response res=given()
		.headers("Authorization", "Bearer "+Auth_Token_sbi)
		.body(requestBody)
		.pathParam("Id", randomValue)
		.when()
		.post(Routes.checker_approve_issuance);

		Data3=res.jsonPath().getString("data");
		System.out.println("CheckerApproveIssuance id is:"+Data3);
		
		 //	validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid Status Code");

	    // Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	    // Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
		
	}
	
}
