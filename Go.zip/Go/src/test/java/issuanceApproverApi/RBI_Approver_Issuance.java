package issuanceApproverApi;

import org.testng.annotations.Test;
import org.testng.Assert;
import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.gherkin.model.When;

import api.endpoints.AuthToken;
import api.endpoints.Routes;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import issuanceCheckerkerApi.Issuance_Checker;

public class RBI_Approver_Issuance implements AuthToken {

	String Data4;
	@Test(priority = 1,enabled = true)
	public void rbi_approver_issuance() {
		Map<String,Object>requestBody=new HashMap<String, Object>();
		requestBody.put("makerRemarks", "regulator-remarks-direct");
		requestBody.put("txnRefNo", "");
		requestBody.put("status", "APPROVE");
		
	 Response res=	  given()
		.headers("Authorization", "Bearer "+Auth_Token)
		.body(requestBody)
		.pathParam("Id",Issuance_Checker.Data3 )
		.when()
		.post(Routes.rbi_approve_issuance);
	String Body= res.getBody().asString();
//	System.out.println(Body);
	JsonPath jp=new JsonPath(Body);
	String formatedJson=jp.prettify();
	System.out.println(formatedJson);
	    Data4=res.jsonPath().getString("data");
		System.out.println("RBI approve issuance id is:"+Data4);
		
		 //	validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid Status Code");

	    // Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	    // Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	
}
