package users;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.AuthToken;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetUsers implements AuthToken {
	@Test
	public void get_Users() {
		Response res = given().headers("Authorization", "Bearer " + Auth_Token).when()
				.get("http://localhost:9002/rrb/api/retail-token-system/v1/users");
		String body = res.getBody().asString();
	    System.out.println(body);
		JsonPath jp = new JsonPath(body);
		String formatedJson = jp.prettify();

		System.out.println(formatedJson);
        
		//Validate the response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid status code");
		// Validate the response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Invalid status line");
		// Validate the response content type
		String contentType = res.getContentType();
		Assert.assertEquals(contentType, "application/json; charset=utf-8", "Invalid content type");

	}

	@Test
	public void permissions() {
		Response res = given()
				.headers("Authorization", "Bearer " + Auth_Token)
				.when()

				.get("http://localhost:9002/rrb/api/retail-token-system/v1/permissions");

		String body = res.getBody().asString();
		JsonPath jp = new JsonPath(body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);
		// Validate the response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid ststus code");
		// Validate the response status line
	    String	stastusLine=res.getStatusLine();
	    Assert.assertEquals(stastusLine, "HTTP/1.1 200 OK","Invalid status line");
	 // Validate the response content type
	    String contentType=res.getContentType();
	    Assert.assertEquals(contentType, "application/json; charset=utf-8", "Invalid content type");

	}
}
