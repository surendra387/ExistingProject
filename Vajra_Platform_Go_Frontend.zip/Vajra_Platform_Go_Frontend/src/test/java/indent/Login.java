package indent;

import java.time.Duration;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.fasterxml.jackson.annotation.JacksonInject.Value;

import genericUtilities.JavaUtility;

public class Login {
	JavaUtility jUtil=new JavaUtility();
	@Test
	public void login() throws InterruptedException {
		WebDriver driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.navigate().to("https://10.25.1.2/retail/tokenrbi/dashboard/ui/login/");
		driver.manage().window().maximize();
		driver.findElement(By.id("details-button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='proceed-link']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("RBIADMIN");
		driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Password@123");
//		Thread.sleep(10000);
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
		for(int i=1;i<=1;i++)
		{
	    System.out.println("iteration "+ i);
		driver.findElement(By.xpath("//span[text()='Creation']")).click();
		driver.findElement(By.xpath("//button[text()=' Create Indent ']")).click();
		WebElement element = driver.findElement(By.xpath("//select[@formcontrolname='denomination']"));
	    Select s=new Select(element);
	    int optionCount=s.getOptions().size();
//		System.out.println(optionCount);
		Random r=new Random();
		int randomIndex=r.nextInt(optionCount);
		s.selectByIndex(randomIndex);	
		s.selectByIndex(5);
		driver.findElement(By.xpath("//input[@type='number']")).sendKeys(toString().valueOf(jUtil.getRandomNumber()));
		driver.findElement(By.xpath("(//button[@type='submit'])[4]")).click();
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test"+jUtil.getRandomNumber());
		driver.findElement(By.xpath("//strong[text()='SUBMIT']")).click();
		Thread.sleep(3000);
		String indentId=driver.findElement(By.xpath("//div[@class='toast-top-right toast-container']")).getText();
		System.out.println(indentId);
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[@aria-hidden='true']")).click();
	    Thread.sleep(3000);
	    Navigation nav = driver.navigate();
		nav.refresh();
		Thread.sleep(2000);
		nav.refresh();
		driver.findElement(By.xpath("//span[text()='Creation']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='Submissions']")).click();
		Thread.sleep(6000);
//////		?######driver.findElement(By.xpath("(//td[@class='c-table__cell'])[1]")).click();
		driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//textarea[@placeholder='Remarks upto 500 characters']")).sendKeys("test");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@id='yes-button']")).click();
		Thread.sleep(2000);
		Navigation nav1 = driver.navigate();
		nav1.refresh();
		Thread.sleep(2000);
		nav1.refresh();
//		System.out.println("This is the approved indent id "+indentId);		
//System.out.println("sbi login");
	}
}}
