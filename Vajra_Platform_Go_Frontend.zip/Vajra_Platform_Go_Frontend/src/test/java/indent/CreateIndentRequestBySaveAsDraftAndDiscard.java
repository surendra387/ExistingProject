package indent;

import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.BaseClass;
import objectRepository.IndentChecker_ApproveIndent;
import objectRepository.IndentMaker_CreateIndent;
import objectRepository.LoginPage;
import objectRepository.HomePage;

public class CreateIndentRequestBySaveAsDraftAndDiscard {
	WebDriver driver=null;
	@Test	
	public void createIndentBySaveAsDraftAndDiscard() throws InterruptedException, IOException {
		PropertyFileUtility pUtil=new PropertyFileUtility();
		
		WebDriverUtility wUtil=new WebDriverUtility();
		
		String RBI_URL=pUtil.readDataFromPropertyFile("rbi_url_2");
		String INDENT_MAKER=pUtil.readDataFromPropertyFile("indentMaker");
		String IM_PASSWORD=pUtil.readDataFromPropertyFile("password");
		String IM_OTP=pUtil.readDataFromPropertyFile("otp");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
	    wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		
        driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.indentMakerLogin(INDENT_MAKER,IM_PASSWORD,IM_OTP);
		HomePage hp = new HomePage(driver);
		hp.creation();		
		IndentMaker_CreateIndent c = new IndentMaker_CreateIndent(driver);
		c.createIndentRequestByDraftAndDiscard();
		Thread.sleep(2000);
		System.out.println("CreateIndentRequestBySaveAsDraftAndDiscard is successfully submitted");
		hp.logout();
		driver.close();
		
	}
}
