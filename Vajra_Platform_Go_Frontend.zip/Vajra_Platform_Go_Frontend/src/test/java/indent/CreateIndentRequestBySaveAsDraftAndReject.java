package indent;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.BaseClass;
import objectRepository.IndentChecker_ApproveIndent;
import objectRepository.IndentMaker_CreateIndent;
import objectRepository.LoginPage;
import objectRepository.RBITokenSummery;
import objectRepository.HomePage;

public class CreateIndentRequestBySaveAsDraftAndReject {
	WebDriver driver = null;

	@Test
	public void createIndentBySaveAsDraftAndReject() throws InterruptedException, IOException {
		PropertyFileUtility pUtil = new PropertyFileUtility();
		WebDriverUtility wUtil = new WebDriverUtility();

		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		String INDENT_MAKER = pUtil.readDataFromPropertyFile("indentMaker");
		String IM_PASSWORD = pUtil.readDataFromPropertyFile("password");
		String IM_OTP = pUtil.readDataFromPropertyFile("otp");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);

		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.indentMakerLogin(INDENT_MAKER, IM_PASSWORD, IM_OTP);
		HomePage hp = new HomePage(driver);
		hp.tokenSummary();
		Thread.sleep(2000);
		RBITokenSummery s = new RBITokenSummery(driver);
		s.BeforeIndnetTokensCount();
		hp.creation();
		IndentMaker_CreateIndent c = new IndentMaker_CreateIndent(driver);
		c.createIndentRequestByDraftAndSubmit();
		hp.logout();
		Thread.sleep(2000);

		String INDENT_CHECKER = pUtil.readDataFromPropertyFile("indentChecker");
		String IC_PASSWORD = pUtil.readDataFromPropertyFile("password");
		lp.indentCheckerLogin(INDENT_CHECKER, IC_PASSWORD, IM_OTP);

		IndentChecker_ApproveIndent ap = new IndentChecker_ApproveIndent(driver);
		hp.creation();
		ap.rejectIndentRequest();
		Thread.sleep(2000);
		Navigation n = driver.navigate();
		n.refresh();
//		while (true) {
//		    try {
//		        driver.navigate().refresh();
//		        
////		        String STATUS = driver.findElement(By.xpath("(//b[contains(text(),'Processed')])[1]")).getText();
//		    	 String STATUS = driver.findElement(By.xpath("/html/body/app-root/app-common-layout/div/main/div/div/div/app-indent-list/div/div[2]/div/table/tbody/tr[1]/td[4]/div")).getText();
//		         System.out.println(STATUS);
//		        
//		        if (STATUS.equalsIgnoreCase("Rejected")) {
//		            System.out.println("Request Rejected Successfully");
//		            break; 
//		        } else {
//		            System.out.println("Current Status is " + STATUS + " Waiting for the request to be processed");
//		        }
//		        
//		        Thread.sleep(10000); 
//		    } catch (Exception e) {
//		        System.out.println(e);
//		    }
//		}
		Thread.sleep(2000);

		hp.tokenSummary();

		s.AfterIndnetTokensCount();

		Thread.sleep(2000);

		s.compareIndnetReject();
		Thread.sleep(2000);
		hp.logout();

		System.out.println("CreateIndentRequestBySaveAsDraftAndReject is successfully submitted");
		driver.quit();
	}
}
