package login;

import org.testng.annotations.Test;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.LoginPage;

public class BANK_Login {
	WebDriver driver = null;

	PropertyFileUtility pUtil = new PropertyFileUtility();
	WebDriverUtility wUtil = new WebDriverUtility();

	@Test(priority = 1)
	public void tc_2_52() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("TSPADMIN");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'TSPADMIN' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 2)
	public void tc_2_55() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','TSPA DM IN')", lp.getUserEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("TSPADMIN LOGIN FAILED DUE TO SPACES IN USERNAME  'TSPA DM IN'");
		}
		driver.close();
	}

	@Test(priority = 3)
	public void tc_2_56() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','tspadmin')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println("TSPADMIN LOGIN FAILED DUE TO ENTERING CASE SENSETIVE IN USERNAME FIELD  'tspadmin'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 4)
	public void tc_2_57() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("TSPADMIN", "Abcd@12356", "999999");
		System.out.println("TSPADMIN LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 5)
	public void tc_2_58() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("TSPADMIN");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println("TSPADMIN LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 6)
	public void tc_2_59() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("TSPADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out
					.println("TSPADMIN LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 7)
	public void tc_2_60() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("TSPADMIN", "PASSWORD@123", "999999");
		System.out.println("TSPADMIN LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 8)
	public void tc_2_53() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("TSPADMINP", "Password@123", "999999");
		System.out.println("TSPADMIN LOGIN FAILED DUE TO ENTERING WRONG USERNAME 'TSPADMINP'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 9)
	public void tc_2_54() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("    ");
		lp.getPwdEdt().sendKeys("Password@123");
		System.out.println("TSPADMIN LOGIN FAILED DUE TO WHILE ENTERING EMPTY USERNAME SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 10)
	public void tc_2_61() throws InterruptedException, IOException {
		String SBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(SBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("ISSUANCE-MAKER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'ISSUANCE-MAKER' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 11)
	public void tc_2_62() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','ISSUANCE-MA KER')", lp.getUserEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("ISSUANCE MAKER LOGIN FAILED DUE TO SPACES IN USERNAME  'ISSUANCE-MA KER'");
		}
		driver.close();
	}

	@Test(priority = 12)
	public void tc_2_63() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','issuance-maker')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"ISSUANCE MAKER LOGIN FAILED DUE TO ENTERING CASE SENSETIVE IN USERNAME FIELD  'issuance-maker'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 13)
	public void tc_2_64() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("ISSUANCE-MAKER", "Abcd@12356", "999999");
		System.out.println("ISSUANCE MAKER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 14)
	public void tc_2_65() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("ISSUANCE-MAKER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println(
				"ISSUANCE-MAKER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 15)
	public void tc_2_66() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("ISSUANCE-MAKER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"ISSUANCE-MAKER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 16)
	public void tc_2_67() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("ISSUANCE-MAKER", "PASSWORD@123", "999999");
		System.out.println("ISSUANCE-MAKER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 17)
	public void tc_2_68() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("ISSUANCE-CHECKER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'ISSUANCE CHECKER'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 18)
	public void tc_2_69() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','ISSUANCE-CHEC KER')", lp.getUserEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("ISSUANCE CHECKER LOGIN FAILED DUE TO SPACES IN USERNAME  'ISSUANCE-CHEC KER'");
		}
		driver.close();
	}

	@Test(priority = 19)
	public void tc_2_70() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','issuance-checker')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"ISSUANCE CHECKER LOGIN FAILED DUE TO ENTERING CASE SENSETIVE IN USERNAME FIELD  'issuance-checker'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 20)
	public void tc_2_71() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("ISSUANCE-CHECKER", "Abcd@12356", "999999");
		System.out.println("ISSUANCE-CHECKER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 21)
	public void tc_2_72() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("ISSUANCE-CHECKER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println(
				"ISSUANCE-CHECKER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 22)
	public void tc_2_73() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("ISSUANCE-CHECKER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"ISSUANCE-CHECKER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 23)
	public void tc_2_74() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("ISSUANCE-CHECKER", "PASSWORD@123", "999999");
		System.out.println("ISSUANCE-CHECKER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 24)
	public void tc_2_75() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("REDEEM-MAKER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'REDEEM MAKER'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 25)
	public void tc_2_76() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','REDEEM-MAK ER')", lp.getUserEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("REDEEM MAKER LOGIN FAILED DUE TO SPACES IN USERNAME  'REDEEM-MAK ER'");
		}
		driver.close();
	}

	@Test(priority = 26)
	public void tc_2_77() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','redeem-maker')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"REDEEM MAKER LOGIN FAILED DUE TO ENTERING CASE SENSETIVE IN USERNAME FIELD  'redeem-maker'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 27)
	public void tc_2_78() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("REDEEM-MAKER", "Abcd@12356", "999999");
		System.out.println("REDEEM-MAKER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 28)
	public void tc_2_79() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("REDEEM-MAKER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println(
				"REDEEM-MAKER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 29)
	public void tc_2_80() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("REDEEM-MAKER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"REDEEM-MAKER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 30)
	public void tc_2_81() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("REDEEM-MAKER", "PASSWORD@123", "999999");
		System.out.println("REDEEM-MAKER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 31)
	public void tc_2_82() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//	System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("REDEEM-CHECKER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'REDEEM-CHECKER'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 32)
	public void tc_2_83() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//	lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','REDEEM-CHEC KER')", lp.getUserEdt());
		} catch (Exception e) {
//		System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("REDEEM CHECKER LOGIN FAILED DUE TO SPACES IN USERNAME  'REDEEM-CHEC KER'");
		}
		driver.close();
	}

	@Test(priority = 33)
	public void tc_2_84() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//	System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//	lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','redeem-checker')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"REDEEM CHECKER LOGIN FAILED DUE TO ENTERING CASE SENSETIVE IN USERNAME FIELD  'redeem-checker'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 34)
	public void tc_2_85() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
//	System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("REDEEM-CHECKER", "Abcd@12356", "999999");
		System.out.println("REDEEM-CHECKER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 35)
	public void tc_2_86() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("REDEEM-CHECKER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println(
				"REDEEM-CHECKER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 36)
	public void tc_2_87() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("REDEEM-CHECKER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//		System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"REDEEM-CHECKER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 37)
	public void tc_2_88() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("REDEEM-CHECKER", "PASSWORD@123", "999999");
		System.out.println("REDEEM-CHECKER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}
}
