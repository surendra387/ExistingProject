package login;

import org.testng.annotations.Test;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.LoginPage;

public class RBI_Login {
	WebDriver driver = null;

	PropertyFileUtility pUtil = new PropertyFileUtility();
	WebDriverUtility wUtil = new WebDriverUtility();

	@Test(priority = 1)
	public void tc_2_1() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("RBIADMIN");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("Successful Login the user 'RBIADMIN' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 2)
	public void tc_2_2() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("RBIADMIN123", "Password@123", "999999");
		System.out.println("RBIADMIN LOGIN FAILED DUE TO INVALID USERNAME 'RBIADMIN123'");
		Thread.sleep(2000);
		driver.close();
	}

	@Test(priority = 3)
	public void tc_2_3() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("      ");
		lp.getPwdEdt().sendKeys("Password@123");
		System.out.println("SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 4)
	public void tc_2_4() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','RBI   ADMIN')", lp.getUserEdt());
		} catch (Exception e) {
			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("RBIADMIN LOGIN FAILED DUE TO SPACES IN USERNAME 'RBI   ADMIN'");
		}
		driver.close();
	}

	@Test(priority = 5)
	public void tc_2_5() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','rbiadmin')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"RBIADMIN LOGIN FAILED DUE TO CASE SENSETIVE IS NOT ALLOWED IN USERNAME FIELD  'rbiadmin'");

		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 6)
	public void tc_2_6() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("RBIADMIN", "Abcd@12356", "999999");
		System.out.println("RBIADMIN LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 7)
	public void tc_2_7() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("RBIADMIN");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println("WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 8)
	public void tc_2_8() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("RBIADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out
					.println("RBIADMIN LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 9)
	public void tc_2_9() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("RBIADMIN", "PASSWORD@123", "999999");
		System.out.println("RBIADMIN LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 10)
	public void tc_2_10() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("INDENT-MAKER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'INDENT-MAKER' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 11)
	public void tc_2_11() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','INDENT-  MAKER')", lp.getUserEdt());
		} catch (Exception e) {
			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("INDENT_MAKER LOGIN FAILED DUE TO SPACES IN USERNAME  'INDENT-  MAKER'");
		}
		driver.close();
	}

	@Test(priority = 12)
	public void tc_2_12() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','indent-maker')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"INDENT-MAKER LOGIN FAILED DUE TO CASE SENSETIVE IS NOT ALLOWED IN USERNAME FIELD  'indent-maker'");

		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 13)
	public void tc_2_13() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("INDENT-MAKER", "Abcd@12356", "999999");
		System.out.println("INDENT-MAKER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 14)
	public void tc_2_14() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("INDENT-MAKER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println("INDENT-MAKER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 15)
	public void tc_2_15() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("INDENT-MAKER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"INDENT-MAKER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'   ");
		}
		driver.close();
	}

	@Test(priority = 16)
	public void tc_2_16() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("INDENT-MAKER", "PASSWORD@123", "999999");
		System.out.println("INDENT-MAKER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 17)
	public void tc_2_17() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("INDENT-CHECKER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'INDENT-CHECKER' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 18)
	public void tc_2_18() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','INDENT-  CHECKER')", lp.getUserEdt());
		} catch (Exception e) {
			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("INDENT-CHECKER LOGIN FAILED DUE TO SPACES IN USERNAME  'INDENT-  CHECKER'");
		}
		driver.close();
	}

	@Test(priority = 19)
	public void tc_2_19() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','indent-checker')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println("INDENT-CHECKER LOGIN FAILED DUE TO CASE SENSETIVE IS NOT ALLOWED IN USERNAME FIELD  'indent-checker'");

		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 20)
	public void tc_2_20() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("INDENT-CHECKER", "Abcd@12356", "999999");
		System.out.println("INDENT-CHECKER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 21)
	public void tc_2_21() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("INDENT-CHECKER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println("INDENT-CHECKER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 22)
	public void tc_2_22() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("INDENT-CHECKER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"INDENT-CHECKER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'   ");
		}
		driver.close();
	}

	@Test(priority = 23)
	public void tc_2_23() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("INDENT-CHECKER", "PASSWORD@123", "999999");
		System.out.println("INDENT-CHECKER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 24)
	public void tc_2_24() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("ISSUANCE-APPROVER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'ISSUANCE-APPROVER' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 25)
	public void tc_2_25() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','ISSUANCE-    APPROVER')", lp.getUserEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("ISSUANCE-APPROVER LOGIN FAILED DUE TO SPACES IN USERNAME  'ISSUANCE-  APPROVER'");
		}
		driver.close();
	}

	@Test(priority = 26)
	public void tc_2_26() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','issuance-approver')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"ISSUANCE-APPROVER LOGIN FAILED DUE TO CASE SENSETIVE IS NOT ALLOWED IN USERNAME FIELD  'issuance-approver'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 27)
	public void tc_2_27() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("ISSUANCE-APPROVER", "Abcd@12356", "999999");
		System.out.println("ISSUANCE-APPROVER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 28)
	public void tc_2_28() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("ISSUANCE-APPROVER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println("ISSUANCE-APPROVER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 29)
	public void tc_2_29() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("ISSUANCE_APPROVER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println(
					"ISSUANCE-APPROVER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 30)
	public void tc_2_30() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("ISSUANCE-APPROVER", "PASSWORD@123", "999999");
		System.out.println("ISSUANCE-APPROVER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}

	@Test(priority = 31)
	public void tc_2_31() throws InterruptedException, IOException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("REDEEM-APPROVER");
		lp.getPwdEdt().sendKeys("Password@123");
		lp.getSignBtn().click();
		lp.getOtpEdt().sendKeys("999999");
		lp.getSubBtn().click();
		System.out.println("SUCCESSFULLY LOGIN THE USER 'REDEEM-APPROVER' ");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 32)
	public void tc_2_32() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','REDEEM-    APPROVER')", lp.getUserEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED USERNAME FIELD");
		} finally {
			System.out.println("REDEEM-APPROVER LOGIN FAILED DUE TO SPACES IN USERNAME  'REDEEM -APPROVER'");
		}
		driver.close();
	}

	@Test(priority = 33)
	public void tc_2_() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
//		lp.getUserEdt().sendKeys("RBI ADMIN");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','redeem-approver')", lp.getUserEdt());
		} catch (Exception e) {
		} finally {
			System.out.println(
					"REDEEM-APPROVER LOGIN FAILED DUE TO CASE SENSETIVE IS NOT ALLOWED IN USERNAME FIELD  'redeem-approver'");
		}
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 34)
	public void tc_2_34() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
//		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("REDEEM-APPROVER", "Abcd@12356", "999999");
		System.out.println("REDEEM-APPROVER LOGIN FAILED DUE TO ENTERING WRONG PASSWORD 'Abcd@12356'");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 35)
	public void tc_2_35() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.getAdvance().click();
		lp.getLink().click();
		lp.getUserEdt().sendKeys("REDEEM-APPROVER");
		lp.getPwdEdt().sendKeys("      ");
		System.out.println("REDEEM-APPROVER LOGIN FAILED DUE TO WHILE ENTERING EMPTY PASSWORD SIGN IN BUTTON IS NOT ENABLED");
		Thread.sleep(1000);
		driver.close();
	}

	@Test(priority = 36)
	public void tc_2_36() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		try {
			lp.getAdvance().click();
			lp.getLink().click();
			lp.getUserEdt().sendKeys("REDEEM-APPROVER");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('value','Password   @123')", lp.getPwdEdt());
		} catch (Exception e) {
//			System.out.println("SPACE IS NOT ALLOWED IN PASSWORD FIELD");
		} finally {
			System.out.println("REDEEM-APPROVER LOGIN FAILED DUE TO SPACES ARE NOT ALLOWED IN PASSWORD FIELD 'Password   @123'");
		}
		driver.close();
	}

	@Test(priority = 37)
	public void tc_2_37() throws IOException, InterruptedException {
		String RBI_URL = pUtil.readDataFromPropertyFile("rbi_url_2");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.userNameAndPassword("REDEEM-APPROVER", "PASSWORD@123", "999999");
		System.out.println("REDEEM-APPROVER LOGIN FAILED DUE TO CASE SENSETIVE PASSWORD 'PASSWORD@123'");
		driver.close();
	}
}
