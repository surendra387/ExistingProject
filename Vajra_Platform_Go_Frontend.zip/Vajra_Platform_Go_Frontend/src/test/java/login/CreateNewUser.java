package login;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.JavaUtility;
import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.HomePage;
import objectRepository.LoginPage;
import objectRepository.UserManagemant;

public class CreateNewUser {
	WebDriver driver = null;

JavaUtility jUtil=new JavaUtility();
WebDriverUtility wUtil=new WebDriverUtility();
PropertyFileUtility pUtil=new PropertyFileUtility();
@Test
public void createuserTest() throws IOException, InterruptedException
{
	String RBI_URL=pUtil.readDataFromPropertyFile("rbi_url_2");
	String RBI_USERNAME=pUtil.readDataFromPropertyFile("username");
	String RBI_PASSWORD=pUtil.readDataFromPropertyFile("password");
	String RBI_OTP=pUtil.readDataFromPropertyFile("otp");

	driver = new EdgeDriver();
    wUtil.maximiseWindow(driver);
	wUtil.waitForElementToLoadInDom(driver);
	
    driver.navigate().to(RBI_URL);
	LoginPage lp = new LoginPage(driver);
	lp.rbiadmin(RBI_USERNAME,RBI_PASSWORD,RBI_OTP);
	HomePage hp = new HomePage(driver);
	hp.userManagement();
	UserManagemant um=new UserManagemant(driver);
	 
    um.createNewUser(jUtil.generateRandomString(6), jUtil.generateRandomString(5)+"@gamil.com","A"+jUtil.generateRandomString(7)+"@9875");
    
    hp.logout();
    driver.quit();

}

}
