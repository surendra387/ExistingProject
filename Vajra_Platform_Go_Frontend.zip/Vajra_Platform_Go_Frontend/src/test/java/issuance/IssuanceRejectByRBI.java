package issuance;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.BaseClass;
import objectRepository.IssuanceApprover;
import objectRepository.LoginPage;
import objectRepository.RBITokenSummery;
import objectRepository.HomePage;

public class IssuanceRejectByRBI{
	 WebDriver driver;

    @Test
	public void rejectIssuanceTest() throws Throwable {	
    	
	PropertyFileUtility pUtil=new PropertyFileUtility();
	WebDriverUtility wUtil=new WebDriverUtility();
	
	String rbi_url=pUtil.readDataFromPropertyFile("rbi_url_2");
	String ISSUANCE_APPROVER=pUtil.readDataFromPropertyFile("issuanceApprover");
	String IA_PASSWORD=pUtil.readDataFromPropertyFile("password");
	String IA_OTP=pUtil.readDataFromPropertyFile("otp");

	driver = new EdgeDriver();
    wUtil.maximiseWindow(driver);
	wUtil.waitForElementToLoadInDom(driver);

    driver.get(rbi_url); 
   
    LoginPage lp =new LoginPage(driver);
    
    lp.issuanceApproverLogin(ISSUANCE_APPROVER, IA_PASSWORD, IA_OTP);
    HomePage hp=new HomePage(driver);
    hp.tokenSummary();
	Thread.sleep(2000);
	RBITokenSummery s=new RBITokenSummery(driver);
	s.BeforeIssuanceTokensCount();
	hp.issuance();
	
	IssuanceApprover ia=new IssuanceApprover(driver);
	ia.rejectIssuance();
	Thread.sleep(2000);
	
	hp.tokenSummary();

	s.AfterIssuanceTokensCount();
	
	Thread.sleep(2000);
	
	s.compareIssunaceReject();
	Thread.sleep(3000);
	hp.logout(); 
	Thread.sleep(1000);
	System.out.println("RBI Issuance Approver  successfully REJECTED");
	driver.quit();
	}
}
