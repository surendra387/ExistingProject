package issuance;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.BANKTokenSummery;
import objectRepository.HomePage;
import objectRepository.LoginPage;

public class TokenSummeryValidationAfterProcessed {
	WebDriver driver;

	@Test
	public void TokenValidation() throws InterruptedException, IOException {
		PropertyFileUtility pUtil = new PropertyFileUtility();
		WebDriverUtility wUtil = new WebDriverUtility();

		String SBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		String ISSUANCE_MAKER = pUtil.readDataFromPropertyFile("issaunceMaker");
		String IM_PASSWORD = pUtil.readDataFromPropertyFile("password");
		String IM_OTP = pUtil.readDataFromPropertyFile("otp");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);

		driver.navigate().to(SBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.issuanceMakerLogin(ISSUANCE_MAKER, IM_PASSWORD, IM_OTP);
		HomePage hp = new HomePage(driver);
		hp.bankTokenSummary();
		Thread.sleep(2000);
		BANKTokenSummery s=new BANKTokenSummery(driver);
		s.compareIssuanceProcessed();
}
}