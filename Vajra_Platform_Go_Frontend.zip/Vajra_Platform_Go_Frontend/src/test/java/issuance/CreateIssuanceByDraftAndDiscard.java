package issuance;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.BaseClass;
import objectRepository.IssuanceApprover;
import objectRepository.IssuanceChecker;
import objectRepository.IssuanceMaker;
import objectRepository.LoginPage;
import objectRepository.HomePage;

public class CreateIssuanceByDraftAndDiscard {
	WebDriver driver;

	@Test
	public void createIssuanceBySaveAsDraftAndDiscard() throws InterruptedException, IOException {
		PropertyFileUtility pUtil = new PropertyFileUtility();
		WebDriverUtility wUtil = new WebDriverUtility();

		String SBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		String ISSUANCE_MAKER = pUtil.readDataFromPropertyFile("issaunceMaker");
		String IM_PASSWORD = pUtil.readDataFromPropertyFile("password");
		String IM_OTP = pUtil.readDataFromPropertyFile("otp");
		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);

		driver.navigate().to(SBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.issuanceMakerLogin(ISSUANCE_MAKER, IM_PASSWORD, IM_OTP);
		HomePage hp = new HomePage(driver);
		hp.issuance();
		Thread.sleep(2000);
		IssuanceMaker im = new IssuanceMaker(driver);
//		im.createIssuanceBySubmit();
		im.createIssuanceByDraftAndDiscard();
		Thread.sleep(2000);
		hp.logout();
		
//		String ISSUANCE_CHECKER = pUtil.readDataFromPropertyFile("issuanceChecker");
//		String IC_PASSWORD = pUtil.readDataFromPropertyFile("password");
//		String IC_OTP = pUtil.readDataFromPropertyFile("otp");
//		lp.issuanceCheckerLogin(ISSUANCE_CHECKER, IC_PASSWORD, IC_OTP);
//		hp.issuance();
//		IssuanceChecker ic = new IssuanceChecker(driver);
//		ic.checkerApproveIssuance();
//		Thread.sleep(2000);
//		Navigation n = driver.navigate();
//		n.refresh();
//		Thread.sleep(2000);
//		hp.logout();
//		Thread.sleep(2000);
////		driver.close();
		System.out.println("Draft Issuance Request  is successfully Discared");
		driver.quit();	

	}
}
