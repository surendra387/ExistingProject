package redeem;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RtspApi {

	// Initial list of 100 tokens (example with 6 tokens, expand as needed)
	private static List<String> tokenIds = new ArrayList<>(
			List.of("00410b2846b620088a6e65afbaec35f3f5929015fbbb51b98d00588cacb61778",
					"00417ef3ff358dcd4b4f34666a934c1f04d10ef9964ea1282353a97eb7ed5c9e",
					"0042644a551e5ce5d57f4dcc94f193ab935267f8f86782d1d8d60c2c88998563",
					"004516b0119e2065bb59a01c266b23a4dd2a5fb24a9b528f8f644fe0f2431771",
					"004645cc98d4f5dbf17b1590f4b3279a575a74b53a817fa9e6e21cac3473ea2e",
					"00466cbfd4d60bd392d8a3be7a92cb88b0039d15d710b53e44d0efc6911a42c6",
					"0048c4cb2354846c282d14ff2e579cb6fc7733820f902f1360f5daa5f2b94e72",
					"0048e2cf62712b53501ebd460c600853fe00539a753fbe3ac502c9f45ec912f7",
					"0049cca0283f735e78cde004ca28eef54661c21bd864e3cf359d1c647411a898",
					"004a952d7875788bb04465f9461d4ae900fa0c2f2c99239887d338002c4aa47c",
					"004c20c1246d8c15f74b423fe0cf0c03290ec34609cb7d88d7c66b529a930388",
					"004d4a5e6ffb92e26dff4862dc5980bfbfe0a5844f83be7a5edccb260cd54370",
					"004e0b3ad4922e6fadc985183e5dc100dcb23576aa5367f93fb8af021ffee9c4",
					"00551ae98487a406c4ce65b155f5b3e72a07b4c57f6a65838d13c708a923d609",
					"00552f850e162745aa63ae1d164661cabdd6349cfc780c39fc38f7ca9a74f998",
					"0058831827f05517816fd37f58408cdf17da82b1e6611ffca188b2a413eba5e6",
					"0059a2eba3f7e3551f93fc5ff70affa3338c91d2e4f7ad1bc610ba7c4a73f6f1",
					"005c2fd15d98743b7e74b14c966d08701e53124bb783dd7f31172b90f1d95c91",
					"005d40624813a5ac1ffe9e05da844596cf05ca2c8889f8fb77fa8a5c0a1dfe1d",
					"005e2e41f97585ca3eb79deb93ae95cf21490e3942d3a8bdc54d274534334dd3",
					"005ecd87542a3ca2e1a1415cdc89f669f9bfb81cc00871567ed8763089eaa538",
					"0060d1fbadd1d58f082c4fbf57fd652a75ba83825b60f6fe9c2b119765ef4721",
					"0060d54e506f14e940d242dbe9794e9cdcb54a9f0d35d2a280872ba33d5c3099",
					"0061a35946916dec1fe23ffd7f8f751d6f0d944d9fa96c73edf8e347a10dd159",
					"0065d910bfa530c336bfc46b0f8b8cb72e1a884104980064bab326331349cb6a",
					"006659499c8882b6dd5c3e5ffc10724f48ebbdc3b022a6d497124ba3802ad449",
					"00682ef68197e5b5b73f98c5e89c7e13fb9ebd515278beafc68512429a1cc1d3",
					"0069971462d987c55bfeb23d753ef5444b9f07c60e44bfba5b7b7a6525280afb",
					"006d5e93c32a33f903c84f0a6837ca630ba3ccdc91a45582aa852631fda0761d",
					"006ddb3edfc49a5f4ce8082044c71fbb66e0d458f47e37af56f800467b5fd572",
					"006f5843d5c5bf225bbd457b2d463acb896b2d57c1c9cc79806a2978d62e4957",
					"0070e0e25ac765da18df49cbba74025ac13f3465e4c4ddf54f31099c46b5048c",
					"007254885571c271515fafe01e17362b7300161998e18a35b932beeda5d2dd33",
					"00754a5d0caba4aeca459e62239fc7517490404307e809cbe8f577c49984f51f",
					"007573b5418ffbb0fe14aca8e53c4ed81c8a08f8f20267c346d0c0a9dd8e7a3a",
					"0076ce7aa571c19d5acf027088c59d75cce2899323ca96767a3685c30cc7bef3",
					"0078583397d8007d7e18083f6b2b060a3e02e6a8b7fd1c9c2b38f400734d2dfe",
					"007a3298c45ca716b1410eab980c9a7be8e51da0bfcb15e4b97c18272056b797",
					"007b3a6c097182c285129360ac357403406c2b2c8aa768f27fa6e11d563917b6",
					"007e3d4e876c36014f29656e331fd22090744f990cdfe2eda1340e9ca279b7a7",
					"00848df20585dc3f9a81255bab873615178b05a2ff34cf95c284edc3e4928be2",
					"0087dd3a7541d8e2ea32a8829441f014ea873cf734bee88696c42cdbfd694e10",
					"0088fdd55804f836b614e7f39b5bb7e65b2ffc2801655d7bb38aaaa266035220",
					"008a8a4655fbc8560a755d1ed0b2fba1f769600614b3392192badf353b328de2",
					"008c96015524a0a8284ab7b66c36dbebf6b99fcd0f9abde5804ded3396f58a00",
					"008ddb7c05cef827faae54dad9013d2faeada6d16c626e4892fd5e51bda8f88b",
					"008e7e067af6fc4e81747a5664bdae9474dad760e1b5e724aba41711cc1bc57a",
					"0092dda53deb1b5b2e71911ed6cb8429d981fe510fb2ef42b55038f2851f1fb1",
					"00965e3466529405b31424a4a6146ef333f676cc535fc01d4277447dd5a9c60c",
					"009b499479cf6ad550f57f0c034edf9097891a9e75c8ec15d901c7265a03797c",
					"009c22feb030cbb5ddc596c611121174a46264cd43460b85e567eaa57521be04",
					"009fb79f4e94c77c66706cb27b9623ea7711b7e3a9fcf3683941667d0c3e6920",
					"00a1083403ef96a23f7d436b4e80c0136061dbceb00b564ca92e7f98a836100c",
					"00a139efa6ac75735f191f955a34bc21f1164bf647ebd4f2b9d1f75e4a7c11d0",
					"00a47fb2f000e419fc118f96d9c342e75d02f13a6207f5d2179a049cd8f716cf",
					"00a7831d5785bbfc51406db20385f08a034dbfb5b3351897ae2e79e868be749b",
					"00aa6823f37bf53804a29df44ae17d861aa457ba5e1fa340c0ae00e69388d0ec",
					"00abc4fe71a6aabda16862e6d67995180f3326e8965596e090910e62ab7cc27d",
					"00af62841077b69f703aa163f56675cd0108e3fc569f47c7b914a74d507c7272",
					"00b0f347ad56236ef3815100d253462dbaa4216fe7527fbe78d3beb1baef6af4",
					"00b247758d4f2502bea06e69c37538388f7830bdae327a6d28f7a921b038ad98",
					"00b3bcdc86f06f02d41b960ebb878d7bc802985db9f5e798fa3c672f3fc737ad",
					"00b4bf24fff921772c80648cc2a2d95820623b69a86822a871588141ff2723a9",
					"00b69677020e452959f89176d736f50ac85151ec14d74869a68fe85f2b3aa374",
					"00b76c3240eb8c654698ec8df4982b9f6aa1d8c6641822a6de33cc9e2a456462",
					"00b7e5607403edf56f7a739029eae0c07d97eee9bfbcbd3e6c638e05bd525f66",
					"00ba0ce0dfe4aa3fbf75bc951bd8e4393d9c0685445379f521013e2b4db4e0aa",
					"00bafc38af9a5088fc2bd96bce006c7ae11194b3d8ee0920bbec573f9ed3eeda",
					"00bdd2056370fd736835f1b67ec12133cfd290e1ef7161a7951ca1d130943287",
					"00bdfd5961dfd3769229cf7a371859e159e0fa9b149e6ca0b1b5e2328480a604",
					"00c1b9461fc5a7b130d4569a228448ff9592f5cdddfa97b7e07f22dd7cf0df64",
					"00c2d2c83a1ffeaf3d119c7f026f1a8bb17004c4ba49f5c311ed0ee02864b83b",
					"00c2eae3cfa3fcc63c41ea9a6e8891af9ae1b7f8147f71c0e9f775d7fd9f3368",
					"00c66076efc19392b059bd5b94a993d6800af3d4944da2f851279c2296d258c2",
					"00c7fd9879486b971470c8d2a4301a975847584fd26650e4fbffbb407eedd3ae",
					"00c9592bc8f4327e15ebf7be3e265da7f7cc341a770ffd8db1e76efb7e1c3ea3",
					"00ca0e99b1237c297d5cabd54b246b5b7e3a9f34776ceee834427e6b95a4fb46",
					"00ccfa4c24f1fe2f9a0b8b4a16dc7f3d39d9e267e5f143d2af9084383bdf77e3",
					"00ce74d4294b76ca457cdf2e60bb8bd3308e7cd0655f1be3ebfa731ea3e76a89",
					"00cfa05fa1dd883903344d2d995824f7992acaaf502449177162f0fbe0065079",
					"00d0178d12d9640b1d458885932afcd60fa224b78ee406ad2ee954a2aa6206dd",
					"00d2339c696952c0ee61e7c3f44c6d85e0036ee20c53ce9c1e3797368d2e268e",
					"00d31db119059e0ba4a3129ccadb5cb1b00340da67a83ea30ffa94cdadd85818",
					"00d388a82fc330ab283d08e3332c183982a9092c17b783be051f90717b7056e8",
					"00d4c4d845a205bebc15dd1589a45ac4e3ab1194cca1509b3e745f2cc3de83b0",
					"00d5b9599f6647b90482e2cd6d404845e067ae4844103b30ea42bd917823158d",
					"00d7820bb44a4524ac7b82d99313595d34fe21f295b0eca0a0dca4e838a66f19",
					"00da070044237a14be5191b74be8b26995568eed076c7c3e511b1494f7a9c6f4",
					"00da1d3156b5fa560d9d6b91fe4a4e1521d85f53dbb1e2bdae86c6a6e65c02fa",
					"00da1d57ea8b2444cc08ec0be76b94bec3e461c303688bde1b7870343daa87bc",
					"00dadf25e05c09ce48b0c6f2abd31773140619d2cbf4250290a40f039c51c1e8",
					"00dafc7905114e31ef723de20c08241d06852081d0b8e21b7821481cc777004d",
					"00dc1c97040067c0a706d1251f1583a6869d72984f51a1326f416fe8223e77fe",
					"00deba093d59feb826213431872c85a535269b94b8a62eed6bdb3663387a3967",
					"00def0d07ef6a754252c6016c78b198d3d7fc0ac2257518d8218b6a232b3d40b",
					"00def41a0c6359d606805db62e07b5b5eab75853d47046cede8b3ceb19654bef",
					"00df248362d64aa9f92040436abd00e73cf0c5021a256059c35abb996ae557ba",
					"00e132ff794d081179861317fa2c8b16acaf44da52d98dd29a9bfe73899eeb68",
					"00e2b7c7a01288a6e3646519bdd03ac9a248b7b92c5125005111bf0eceb96340",
					"00e4e5ed34bc125fbc926482ed6072a7249163bc5d97226309b66a6576349b91"

			// Add more tokens here until you reach 100
			));

	public static void main(String[] args) {
        // Set base URI to the localhost server
//        RestAssured.baseURI = "https://localhost:2760";

        // Assume this method retrieves requestId from another API response
        String requestId = "R-2024-RD-7325-35baf93095";

        // Send multiple requests with random tokens
        while (tokenIds.size() >= 3) {
            sendRequestWithRandomTokens(requestId, 3);
        }
    }


    public static void sendRequestWithRandomTokens(String requestId, int numTokens) {
        String endpoint = "https://localhost:2804/retail/tokennipl/dashboard/api/token/RespUpdateToken/2.0/urn:txnid::" + requestId;

        // Select a random subset of tokens
        List<String> selectedTokens = selectRandomTokens(numTokens);

        // Build the XML payload
        String xmlPayload = buildXmlPayload(requestId, selectedTokens);

        // Create request specification
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/xml");
        request.body(xmlPayload);

        // Send POST request
        Response response = request.post(endpoint);

        // Print response
        System.out.println("Response Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());
    }

    private static List<String> selectRandomTokens(int numTokens) {
        List<String> selectedTokens = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < numTokens && !tokenIds.isEmpty(); i++) {
            int randomIndex = random.nextInt(tokenIds.size());
            selectedTokens.add(tokenIds.remove(randomIndex)); // Remove after selection
        }

        return selectedTokens;
    }

    private static String buildXmlPayload(String requestId, List<String> tokenIds) {
        StringBuilder tokensXml = new StringBuilder();
        for (String tokenId : tokenIds) {
            tokensXml.append("                <Token id=\"").append(tokenId).append("\"/>\n");
        }

        return "<ns2:RespUpdateToken xmlns:token=\"http://npci.org/token/schema/\">\n" +
                "    <Head ver=\"1.0\" ts=\"\" orgId=\"678910\" msgId=\"" + requestId + "\"/>\n" +
                "    <ResDetails type=\"CHECKREDEEM\">\n" +
                "        <Resp reqMsgId=\"ajdhhhlsvc\" result=\"SUCCESS\" errCode=\"\" requestId=\"" + requestId + "\">\n" +
                "            <Tokens>\n" +
                tokensXml +
                "            </Tokens>\n" +
                "        </Resp>\n" +
                "    </ResDetails>\n" +
                "</ns2:RespUpdateToken>";
    }

}