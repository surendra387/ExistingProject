package redeem;

import org.testng.annotations.Test;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.LoginPage;
import objectRepository.HomePage;
import objectRepository.RedeemChecker;
import objectRepository.RedeemMaker;
import objectRepository.RedeemMaker2;

public class CreateRedeemRequestBySubmit {
	WebDriver driver = null;
	PropertyFileUtility pUtil = new PropertyFileUtility();
	WebDriverUtility wUtil = new WebDriverUtility();

	@Test
	public void cretaeRedeemByDraft() throws IOException, InterruptedException {
		String SBI_URL = pUtil.readDataFromPropertyFile("sbi_url_2");
		String REDEEM_MAKER = pUtil.readDataFromPropertyFile("redeemMaker");
		String RM_PASSWORD = pUtil.readDataFromPropertyFile("password");
		String RM_OTP = pUtil.readDataFromPropertyFile("otp");

		driver = new EdgeDriver();
		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);

		driver.navigate().to(SBI_URL);
		LoginPage lp = new LoginPage(driver);
		lp.redeemMakerLogin(REDEEM_MAKER, RM_PASSWORD, RM_OTP);

		HomePage hp = new HomePage(driver);
		hp.redemption();

		RedeemMaker2 rm = new RedeemMaker2(driver);
		rm.createRedeemBySubmit();

		hp.logout();

		String REDEEM_CHECKER = pUtil.readDataFromPropertyFile("redeemChecker");
		String RC_PASSWORD = pUtil.readDataFromPropertyFile("password");
		lp.redeemCheckerLogin(REDEEM_CHECKER, RC_PASSWORD, RM_OTP);
		hp.redemption();
		RedeemChecker rc = new RedeemChecker(driver);
		rc.approveRedeemRequest();
		Thread.sleep(2000);
		hp.logout();
		Thread.sleep(2000);
		driver.quit();
	}
}
