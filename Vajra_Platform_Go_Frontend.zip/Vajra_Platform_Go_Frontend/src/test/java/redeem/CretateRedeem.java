package redeem;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class CretateRedeem {
	@Test(priority = 1)
	public void create_issuance() throws InterruptedException {
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver = new ChromeDriver(options);
		WebDriver driver = new ChromeDriver();
		driver.get("https://10.25.1.2/retail/tokennipl/dashboard/ui/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.id("details-button")).click();
//		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='proceed-link']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("TSPADMIN");
		driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Password@123");
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
		driver.findElement(By.xpath("//span[text()='Redemption']")).click();
		driver.findElement(By.xpath("//button[text()=' Request Redeem ']")).click();
		WebElement element = driver.findElement(By.xpath("//select[@formcontrolname='denomination']"));
		Select s = new Select(element);
		s.selectByValue("500");
		driver.findElement(By.xpath("//input[@type='number']")).sendKeys("10");
		driver.findElement(By.xpath("(//button[@type='submit'])[4]")).click();
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//b[text()='SUBMIT']")).click();
		String RedeemId=driver.findElement(By.xpath("//div[@class='toast-top-right toast-container']")).getText();
		System.out.println(RedeemId);
		Thread.sleep(6000);
		driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).click();
//        String msg=	driver.findElement(By.xpath("(//a[@class='viewDetails'])[1]")).getText();
//		System.out.println(msg);
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		driver.findElement(By.xpath("//button[@id='yes-button']")).click();
		
		System.out.println("Bank checker approved "+RedeemId);
		
		Thread.sleep(2000);
		driver.get("https://10.25.1.2/retail/tokenrbi/dashboard/ui/login/");
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		driver.findElement(By.id("details-button")).click();
////		Thread.sleep(2000);
//		driver.findElement(By.xpath("//a[@id='proceed-link']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("DULAMPAVAN");
		driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Npci@1234");
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
		driver.findElement(By.xpath("//span[text()='Redemption']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//td[@class='c-table__cell'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		driver.findElement(By.xpath("//button[@id='yes-button']")).click();
	}
	}

