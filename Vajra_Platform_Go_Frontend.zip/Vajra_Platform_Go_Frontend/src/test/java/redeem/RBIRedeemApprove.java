package redeem;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class RBIRedeemApprove {
	@Test()
	public void create_issuance() throws InterruptedException {
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver = new ChromeDriver(options);
		WebDriver driver = new ChromeDriver();
		driver.get("https://10.25.1.2/retail/tokenrbi/dashboard/ui/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.id("details-button")).click();
//		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='proceed-link']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("DULAMPAVAN");
		driver.findElement(By.xpath("//input[@placeholder='ENTER PASSWORD']")).sendKeys("Npci@1234");
		driver.findElement(By.xpath("//button[text()=' Sign In ']")).click();
		driver.findElement(By.xpath("//input[@placeholder='ENTER OTP']")).sendKeys("999999");
		driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).click();
		driver.findElement(By.xpath("//span[text()='Redemption']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//td[@class='c-table__cell'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//textarea[@id='remark']")).sendKeys("test");
		driver.findElement(By.xpath("//button[text()=' APPROVE ']")).click();
		driver.findElement(By.xpath("//button[@id='yes-button']")).click();
	}
}
