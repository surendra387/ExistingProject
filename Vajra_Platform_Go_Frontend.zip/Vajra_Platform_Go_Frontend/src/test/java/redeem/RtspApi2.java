package redeem;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class RtspApi2 {
    @Test
    public void redeem() {
        String requestId = "R-2024-RD-7325-35baf93095"; // Set dynamically or get from another response
        String url = "https://localhost:3105/retail/tokennipl/dashboard/api/token/RespUpdateToken/2.0/urn:txnid::"+requestId;

        String body = "<ns2:RespUpdateToken xmlns:token=\"http://npci.org/token/schema/\">\n"
                + "    <Head ver=\"1.0\" ts=\"\" orgId=\"678910\" msgId=\"qwedfghbnzsdrr\"/>\n"
                + "    <ResDetails type=\"CHECKREDEEM\">\n"
                + "        <Resp reqMsgId=\"qwedfghbnzsdrq\" result=\"SUCCESS\" errCode=\"\" requestId=\"" + requestId + "\">\n"
                + "            <Tokens>\n"
                + "                <Token id=\"00a1083403ef96a23f7d436b4e80c0136061dbceb00b564ca92e7f98a836100c\"/>\n"
                + "                <Token id=\"00e4e5ed34bc125fbc926482ed6072a7249163bc5d97226309b66a6576349b91\"/>\n"
                + "            </Tokens>\n"
                + "        </Resp>\n"
                + "    </ResDetails>\n"
                + "</ns2:RespUpdateToken>";

        Response res = given()
            .relaxedHTTPSValidation() // To handle SSL certificates
            .header("Content-Type", "application/xml") // Set XML content type
            .body(body)
            .when()
            .post(url);

        System.out.println("Response: " + res.getBody().asString());
    }
}