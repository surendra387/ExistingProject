package redeem;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;
import objectRepository.BaseClass;
import objectRepository.IssuanceApprover;
import objectRepository.LoginPage;
import objectRepository.RedeemApprover;
import objectRepository.HomePage;

public class RedeemRejectByRBI{
	 WebDriver driver;

    @Test
	public void approveIssuanceTest() throws Throwable {	
    	
	PropertyFileUtility pUtil=new PropertyFileUtility();
	WebDriverUtility wUtil=new WebDriverUtility();
	
	String rbi_url=pUtil.readDataFromPropertyFile("rbi_url_2");
	String REDEEM_APPROVER=pUtil.readDataFromPropertyFile("redeemApprover");
	String RA_PASSWORD=pUtil.readDataFromPropertyFile("password");
	String RA_OTP=pUtil.readDataFromPropertyFile("otp");

	driver = new EdgeDriver();
    wUtil.maximiseWindow(driver);
	wUtil.waitForElementToLoadInDom(driver);

    driver.get(rbi_url); 
   
    LoginPage lp =new LoginPage(driver);
    
    lp.issuanceApproverLogin(REDEEM_APPROVER, RA_PASSWORD, RA_OTP);
    HomePage hp=new HomePage(driver);
    
	hp.redemption();
	
	RedeemApprover ia=new RedeemApprover(driver);
	ia.rejectRedeem();
	Thread.sleep(2000);
	hp.logout();
	Thread.sleep(1000);
	System.out.println("RBI Issuance Approver  successfully REJECTED");
	driver.quit();
	}
}
