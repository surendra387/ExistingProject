package testUtilities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class MariaDBQueryAutomation {
	public static void main(String[] args) {
		 
		
        // Database connection variables
//        String jdbcUrl = "jdbc:mariadb://<kubernetes-service-ip>:3306/<database-name>";
        String jdbcUrl = "jdbc:mariadb://10.221.10.60:3306/rbi";
        String username = "root";
        String password = System.getenv("MARIADB_ROOT_PASSWORD");  // Securely get the password from environment variable

        // SQL query to execute
        String query = "SELECT * FROM your_table";

        // Step 1: Load the MariaDB JDBC driver (not mandatory for newer Java versions)
        try {
            Class.forName("org.mariadb.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MariaDB JDBC Driver not found!");
            e.printStackTrace();
            return;
        }

        // Step 2: Connect to the database
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            
        	  if (connection != null && connection.isValid(2)) { 
	                System.out.println("Successfully connected to the database.");
	            } else {
	                System.out.println("Failed to connect to the database.");
	                return; 
	            }
//        	  System.out.println("Connected to the database.");

            // Step 3: Create a statement object
            Statement statement = connection.createStatement();

            // Step 4: Execute the SQL query
            ResultSet resultSet = statement.executeQuery(query);

            // Step 5: Process the result set
            while (resultSet.next()) {
                // Assuming 'id' and 'name' are columns in your table
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");

                System.out.println("ID: " + id + ", Name: " + name);
            }

        } catch (SQLException e) {
            System.err.println("SQL error occurred:");
            e.printStackTrace();
        }
    }
}

