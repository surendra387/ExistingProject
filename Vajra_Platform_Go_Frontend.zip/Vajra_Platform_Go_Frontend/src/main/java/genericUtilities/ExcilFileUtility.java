package genericUtilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcilFileUtility {
	public Object[][] readMultipleDataFormate(String sheet) throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("/home/pasala.surendra_oli@npci.org.in/Downloads/Book 23.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		Sheet s = wb.getSheet(sheet);
		int lastrow = s.getLastRowNum();
		int lastcell = s.getRow(0).getLastCellNum();
		Object[][] data = new Object[lastrow][lastcell];
		for (int i = 0; i < lastrow; i++) {
			for (int j = 0; j < lastcell; j++) {
				data[i][j] = s.getRow(i + 1).getCell(j).getStringCellValue();
			}
		}
		return data;
	}

	/**
	 * This method will read the data from ExcelFile and returns the value
	 * 
	 * @param sheet
	 * @param row
	 * @param cel
	 * @return
	 * @throws EncryptedDocumentException
	 * @throws IOException
	 */
	public String readDataFromExcelFile(String sheet, int row, int cel) throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("");
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheet);
		Row r = sh.getRow(row);
		Cell cell = r.getCell(cel);
		String value = cell.getStringCellValue();
		wb.close();
		return value;
	}

	/**
	 * This method will give the last row number in the give sheet
	 * 
	 * @param sheet
	 * @return
	 * @throws EncryptedDocumentException
	 * @throws IOException
	 */
	public int getRowCount(String sheet) throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("");
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheet);
		int lastRowNumber = sh.getLastRowNum();
		return lastRowNumber;
	}

	/**
	 * This method is used to write the data in the given excel sheet
	 * 
	 * @param sheet
	 * @param row
	 * @param cell
	 * @param value
	 * @throws EncryptedDocumentException
	 * @throws IOException
	 */
	public void writeDataFromExcelFile(String sheet, int row, int cell, String value)
			throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("");
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheet);
		Row r = sh.getRow(row);
		Cell cel = r.createCell(cell);
		cel.setCellValue(value);
		FileOutputStream fos = new FileOutputStream("");
		wb.write(fos);
		wb.close();
	}
}
