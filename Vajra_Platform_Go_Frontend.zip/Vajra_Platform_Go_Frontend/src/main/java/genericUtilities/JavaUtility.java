package genericUtilities;

import java.util.Date;
import java.util.Random;

/**
 * This class contains all the java generic methods
 */
public class JavaUtility {
	
	private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	private static final Random RANDOM = new Random();
	
	/**
	 * This method will generate random number for every execution
	 * 
	 * @return
	 */
	public int getRandomNumber() {
		Random r = new Random();
		int random = r.nextInt(100) + 1;
		return random;
	}

	/**
	 * This method will generate system date
	 * 
	 * @return
	 */
	public String getSystemDate() {
		Date d = new Date();
		String date = d.toString();
		return date;
	}

	/**
	 * This method will generate Date and time in specific format
	 * 
	 * @return
	 */

	public String getSystemDateInFormate() {
		Date d = new Date();
		String[] dArr = d.toString().split(" ");
		String date = dArr[2];
		String month = dArr[1];
		String year = dArr[5];
		String time = dArr[3].replace(":", "-");
		String currentDataAndTime = date + " " + month + " " + year + " " + time;
		return currentDataAndTime;
	}

	/**
	 * This method will generate random string for every execution
	 * 
	 * @param length
	 * @return
	 */
	public String generateRandomString(int length) {
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			int index = RANDOM.nextInt(CHARACTERS.length());
			sb.append(CHARACTERS.charAt(index));
		}
		return sb.toString();
	}
}
