package genericUtilities;

import java.time.Duration;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class WebDriverUtility {
	/**
	 * This method will handle drop down by select class by "index number"
	 * 
	 * @param visibletext
	 * @param element
	 */
	public void handleDropDown(WebElement element, int index) {
		Select s = new Select(element);
		s.selectByIndex(index);
	}

	/**
	 * This method will handle drop down by select class by "value"
	 * 
	 * @param visibletext
	 * @param element
	 */
	public void handleDropDown(WebElement element, String value) {
		Select s = new Select(element);
		s.selectByValue(value);
	}

	/**
	 * This method will handle drop down by select class by "visibleText"
	 * 
	 * @param visibletext
	 * @param element
	 */
	public void handleDropDown(String visibletext, WebElement element) {
		Select s = new Select(element);
		s.selectByVisibleText(visibletext);
	}

	/**
	 * This method will perform right click ona particular element
	 * 
	 * @param driver
	 * @param element
	 */
	public void rightClickOn(WebDriver driver, WebElement element) {
		Actions act = new Actions(driver);
		act.contextClick(element).perform();
	}
	/**
	 * This method will wait for 20 seconds for the entire DOM structure to load
	 * @param driver
	 */
	public void waitForElementToLoadInDom(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	/**
	 * This method is used to maximize the window
	 * @param driver
	 */
	
	public void maximiseWindow(WebDriver driver)
	{
		driver.manage().window().maximize();
	}
	
	public void dropDownByIndex(WebElement element) {
		Select s=new Select(element);
		int optionCount=s.getOptions().size();
//		System.out.println(optionCount);
		Random r=new Random();
		int randomIndex=r.nextInt(optionCount);
		s.selectByIndex(randomIndex);	
	}
	
}
