package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BANKTokenSummery {
 	String tokensincustody1;
 	String tokensincustody2;
	
	
	public BANKTokenSummery(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//*[@id='token-summary-table']/thead/tr[2]/td[1]")
	private WebElement tokensincustody;
	


	public WebElement getTokensincustody1() {
		return tokensincustody;
	}

	
	public void BeforeTokensCount() throws InterruptedException
	{
		Thread.sleep(2000);
		tokensincustody1 =tokensincustody.getText();
		System.out.println("Before issuance tokens count in SBI token summery :"+ tokensincustody1);
	}
	
	public void AfterTokensCount() throws InterruptedException
	{
		Thread.sleep(2000);
		tokensincustody2 =tokensincustody.getText();
		System.out.println("After issuance tokens count in SBI token summery :"+ tokensincustody2 );
		
	}
	
	public void compareIssuanceProcessed()
	{
		long l1 = Long.parseLong(tokensincustody1);
		long l2 = Long.parseLong(tokensincustody2);
		long l3 = Long.parseLong(IndentMaker_CreateIndent.TokensCount);
		long value=l1-l2;	
		
		if(l3==value)
		{
			System.out.println("Requested Issuance Token are updated successfully with :"+value);
		}
		else
		{
			System.out.println("Requested Issuance Token are not updated successfully with :"+value);

		}
		
	}
	public void compareIssuanceReject()
	{
		long l1 = Long.parseLong(tokensincustody1);
		long l2 = Long.parseLong(tokensincustody2);
//		long l3 = Long.parseLong(IndentMaker_CreateIndent.TokensCount);
		long value=l1-l2;	
//		System.out.println(value);
		if(0==value)
		{
			System.out.println("Token are not updated in DB due to Issuance rejection");
		}
		else
		{
			System.out.println("Requested Token are updated successfully with :"+value);

		}
	}
	
	
}
