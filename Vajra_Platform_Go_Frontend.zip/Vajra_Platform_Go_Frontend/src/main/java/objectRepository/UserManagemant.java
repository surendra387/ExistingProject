package objectRepository;

import java.sql.Driver;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.WebDriverUtility;
import groovy.transform.Final;

public class UserManagemant {
	WebDriverUtility wUtil = new WebDriverUtility();

	public UserManagemant(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//button[text()=' Create User ']")
	private WebElement createUserBtn;

	@FindBy(xpath = "(//input[@formcontrolname='username'])[2]")
	private WebElement userNameEdt;

	@FindBy(xpath = "//input[@type='email']")
	private WebElement emailEdt;

	@FindBy(xpath = "//select[@id='role']")
	private WebElement rolesEdt;

	@FindBy(xpath = "//button[text()=' Add Role ']")
	private WebElement addRoleBtn;

	@FindBy(xpath = "//*[@id='password']")
	private WebElement passwordEdt;

	@FindBy(xpath = "//*[@id='confirm_password']")
	private WebElement confirmPwdEdt;

	@FindBy(xpath = "(//button[text()=' Submit '])[3]")
	private WebElement submitBtn;

	@FindBy(xpath = "//button[text()=' Back ']")
	private WebElement backBtn;

	@FindBy(xpath = "//span[text()='x']")
	private WebElement xBtn;

	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;

	@FindBy(xpath = "(//span[@class='slider round'])[1]")
	private WebElement activeBtn;
	

	public WebElement getactiveBtn() {
		return activeBtn;
	}
	
	public WebElement getCreateUserBtn() {
		return createUserBtn;
	}

	public WebElement getUserNameEdt() {
		return userNameEdt;
	}

	public WebElement getEmailEdt() {
		return emailEdt;
	}

	public WebElement getRolesEdt() {
		return rolesEdt;
	}

	public WebElement getAddRoleBtn() {
		return addRoleBtn;
	}

	public WebElement getPasswordEdt() {
		return passwordEdt;
	}

	public WebElement getConfirmPwdEdt() {
		return confirmPwdEdt;
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public WebElement getBackBtn() {
		return backBtn;
	}

	public WebElement getxBtn() {
		return xBtn;
	}

	public WebElement getIdMsg() {
		return idMsg;
	}

	public void createNewUser(String username, String email, String password) throws InterruptedException {
		createUserBtn.click();
		userNameEdt.sendKeys(username);
		emailEdt.sendKeys(email);
		wUtil.dropDownByIndex(rolesEdt);
		addRoleBtn.click();
		passwordEdt.sendKeys(password);
		confirmPwdEdt.sendKeys(password);
		submitBtn.click();
		Thread.sleep(2000);
		xBtn.click();
		Thread.sleep(2000);
		String msg = idMsg.getText();
		System.out.println(msg);
		Thread.sleep(2000);
	
//		activeBtn.click();
//	    backBtn.click();
	}
}
