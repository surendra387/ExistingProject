package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;

	// parameterized constructor
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Decleration

	@FindBy(xpath = "//*[@id='token-summary-table']/thead/tr[6]/td[1]")
	private WebElement tokenInRbiVault;

	@FindBy(xpath = "//span[text()='Tokens Summary']")
	private WebElement tokenSummertField;

	@FindBy(id = "details-button")
	private WebElement advance;

	@FindBy(id = "proceed-link")
	private WebElement link;

	@FindBy(xpath = "//input[@placeholder='Enter username']")
	private WebElement userEdt;

	@FindBy(xpath = "//input[@placeholder='ENTER PASSWORD']")
	private WebElement pwdEdt;

	@FindBy(xpath = "//button[text()=' Sign In ']")
	private WebElement signBtn;

	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement Msg;

	@FindBy(xpath = "//input[@placeholder='ENTER OTP']")
	private WebElement otpEdt;

	@FindBy(xpath = "(//button[text()=' Submit '])[1]")
	private WebElement subBtn;

	public WebElement getTokenInRbiVault() {
		return tokenInRbiVault;
	}
	
	public WebElement getTokenSummertField() {
		return tokenSummertField;
	}

	public WebElement getAdvance() {
		return advance;
	}

	public WebElement getLink() {
		return link;
	}

	public WebElement getUserEdt() {
		return userEdt;
	}

	public WebElement getPwdEdt() {
		return pwdEdt;
	}

	public WebElement getSignBtn() {
		return signBtn;
	}

	public WebElement getOtpEdt() {
		return otpEdt;
	}

	public WebElement getSubBtn() {
		return subBtn;
	}

	public WebElement getMsg() {
		return Msg;
	}

	public void indentMakerLogin(String username, String password, String otp) throws InterruptedException {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		
		
		Thread.sleep(6000);
		signBtn.click();
		
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println(" Indent Maker Login Successfully ");
	}

	public void rbiadmin(String username, String password, String otp) {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		signBtn.click();
		
		
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println(" RBIADMIN Login Successfully ");
	}

	public void indentCheckerLogin(String username, String password, String otp) throws InterruptedException {
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		
		Thread.sleep(6000);
		signBtn.click();
		
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println(" Indent Checker Login Successfully ");
	}

	public void issuanceMakerLogin(String username, String password, String otp) throws InterruptedException {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		
		Thread.sleep(6000);
		
		
		signBtn.click();
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println("Issuance Maker Login Successfully ");
	}

	public void issuanceCheckerLogin(String username, String password, String otp) throws InterruptedException {
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		
		Thread.sleep(6000);

		signBtn.click();
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println("Issuance Checker Login Successfully");
	}

	public void issuanceApproverLogin(String username, String password, String otp) throws InterruptedException {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		
		Thread.sleep(6000);

		
		signBtn.click();
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println("Issuance Approver Login Successfully ");
	}

	public void redeemMakerLogin(String username, String password, String otp) {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		signBtn.click();
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println(" Redeem Maker Login Successfully ");
	}

	public void redeemCheckerLogin(String username, String password, String otp) {
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		signBtn.click();
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println("Redeem Checker Login Successfully");
	}

	public void redeemApproverLogin(String username, String password, String otp) {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		signBtn.click();
		otpEdt.sendKeys(otp);
		subBtn.click();
//		String msg=Msg.getText();
//		System.out.println(msg);
		System.out.println(" Redeem Approver Login Successfully ");
	}

	public void userNameAndPassword(String username, String password, String otp) throws InterruptedException {
		advance.click();
		link.click();
		userEdt.sendKeys(username);
		pwdEdt.sendKeys(password);
		signBtn.click();
//		otpEdt.sendKeys(otp);
//		subBtn.click();
		Thread.sleep(2000);
		String msg = Msg.getText();
		System.out.println(msg);
	}

}
