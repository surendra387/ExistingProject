package objectRepository;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import genericUtilities.JavaUtility;
import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;

public class BaseClass {
	public PropertyFileUtility pUtil = new PropertyFileUtility();
	public WebDriverUtility wUtil = new WebDriverUtility();
	public JavaUtility jUtil = new JavaUtility();
	public WebDriver driver = null;

	@BeforeClass(groups = {"SmokeSuite","RegerssionSuite"})
	public void bcConfig() throws IOException {
		String RBI_URL=pUtil.readDataFromPropertyFile("rbi_url_2");
		String BROWSER = pUtil.readDataFromPropertyFile("browser");

		if (BROWSER.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
			driver = new ChromeDriver();
			System.out.println("===  Chrome Browser Launched Successfully  ==");
		} else if (BROWSER.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
			System.out.println("===  Edge Browser Launched Successfully  ==");
		}

		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(RBI_URL);
	}

	@BeforeMethod(groups = {"SmokeSuite","RegerssionSuite"})
	public void bmConfig() throws IOException, InterruptedException {
		String USERNAME = pUtil.readDataFromPropertyFile("username");
		String PASSWORD = pUtil.readDataFromPropertyFile("password");
		String OTP=pUtil.readDataFromPropertyFile("otp");
		LoginPage lp = new LoginPage(driver);
		lp.indentMakerLogin(USERNAME, PASSWORD, OTP);
	}

	@AfterMethod(groups = {"SmokeSuite","RegerssionSuite"})
	public void amConfig() throws InterruptedException {
		HomePage hp = new HomePage(driver);
		hp.logout();
		System.out.println("Logout Successfully");
	}

	@AfterClass(groups = {"smokeSuite"})
	public void acConfig() {
		driver.quit();
	}
}
