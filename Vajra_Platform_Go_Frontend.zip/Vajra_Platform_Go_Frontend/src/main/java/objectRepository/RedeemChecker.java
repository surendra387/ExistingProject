package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.JavaUtility;

public class RedeemChecker {
	JavaUtility jUtil = new JavaUtility();

	public RedeemChecker(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//td[@class='c-table__cell'])[1]")
	private WebElement approveRedeemId;

	@FindBy(xpath = "//*[@id='remark']")
	private WebElement chekerRemarksEdt;

	@FindBy(xpath = "//*[@id='approve-button']")
	private WebElement approveBtn;

	@FindBy(xpath = "//button[text()=' REJECT ']")
	private WebElement rejectBtn;

	@FindBy(xpath = "//*[@id='yes-button']")
	private WebElement yesBtn;

	@FindBy(xpath = "//*[@id='no-button']")
	private WebElement noBtn;
	
	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;

	public WebElement getApproveRedeemId() {
		return approveRedeemId;
	}

	public WebElement getChekerRemarksEdt() {
		return chekerRemarksEdt;
	}

	public WebElement getApproveBtn() {
		return approveBtn;
	}

	public WebElement getRejectBtn() {
		return rejectBtn;
	}

	public WebElement getYesBtn() {
		return yesBtn;
	}

	public WebElement getNoBtn() {
		return noBtn;
	}
	
	public WebElement getIdMsg() {
		return idMsg;
	}
	public void approveRedeemRequest() throws InterruptedException {
		approveRedeemId.click();
		chekerRemarksEdt.sendKeys("Approve" + jUtil.getRandomNumber());
		approveBtn.click();
		Thread.sleep(1000);
		yesBtn.click();
		System.out.println("Redeem Checker Approved successfully");
	}

	public void rejetRedeemRequest() throws InterruptedException {
		approveRedeemId.click();
		chekerRemarksEdt.sendKeys("Approve" + jUtil.getRandomNumber());
		rejectBtn.click();
		Thread.sleep(1000);
		yesBtn.click();
		System.out.println("Redeem Cheker Reject successfully");
	}
}
