package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver driver;

//Initilization

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

//Declarartion

	@FindBy(xpath = "//span[text()='Creation']")
	private WebElement creationField;

	@FindBy(xpath = "//span[text()='Issuance']")
	private WebElement issuanceField;

	@FindBy(xpath = "//span[text()='Redemption']")
	private WebElement redeemField;

	@FindBy(xpath = "//*[@id='userDropdownMenu']")
	private WebElement dropDownBtn;

	@FindBy(xpath = "//a[text()='Log out']")
	private WebElement logoutBtn;
	
	@FindBy(xpath = "//span[text()='User Management']")
	private WebElement userManagentBtn;
	
	@FindBy(xpath = "//span[text()='Tokens Summary']")
	private WebElement tokenSummaryField;

	@FindBy(xpath = "//span[text()='Token Summary']")
	private WebElement bankTokenSummaryField;
	
	public WebElement getuserManagentBtn()
	{
		return userManagentBtn;
	}
	public WebElement getCreationField() {
		return creationField;
	}

	public WebElement getIssuanceField() {
		return issuanceField;
	}

	public WebElement getRedeemField() {
		return redeemField;
	}

	public WebElement getDropDownBtn() {
		return dropDownBtn;
	}

	public WebElement logoutBtn() {
		return logoutBtn;
	}
	
	public WebElement getTokenSummaryField()
	{
		return tokenSummaryField;
	}
	public WebElement getBankTokenSummaryField()
	{
		return bankTokenSummaryField;
	}
	
	public void creation() {
		creationField.click();
	}
	public void issuance() {
		issuanceField.click();
	}
	public void redemption() {
		redeemField.click();
	}
	
	public void userManagement() {
		userManagentBtn.click();
	}
	public void tokenSummary()
	{
		tokenSummaryField.click();
	}
	
	public void bankTokenSummary()
	{
		bankTokenSummaryField.click();
	}
	
	
	
	
	
	public void logout() throws InterruptedException {
		Thread.sleep(3000);
		dropDownBtn.click();
        logoutBtn.click();
        System.out.println("===LogOut Successfully===");

      //*[@id="token-summary-table"]/thead/tr[2]/td[1]
	
	}

}
