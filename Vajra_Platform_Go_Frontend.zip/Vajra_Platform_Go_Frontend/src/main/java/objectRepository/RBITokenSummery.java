package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RBITokenSummery {
 	String tokenscreated1;
 	String tokeninRBIvault1;
	
 	String tokenscreated2;
	String tokeninRBIvault2;
	
	
	public RBITokenSummery(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//*[@id='token-summary-table']/thead/tr[2]/td[1]")
	private WebElement tokensCreated;
	
	@FindBy(xpath = "//*[@id='token-summary-table']/thead/tr[6]/td[1]")
	private WebElement tokensInRbiValut;

	public WebElement getTokensCreated() {
		return tokensCreated;
	}

	public WebElement getTokensInRbiValut() {
		return tokensInRbiValut;
	}
	
	public void BeforeIndnetTokensCount() throws InterruptedException
	{
		Thread.sleep(2000);
		 tokenscreated1=tokensCreated.getText();
		System.out.println("Before Indnet creation created tokens count :"+ tokenscreated1);
		Thread.sleep(2000);
		 tokeninRBIvault1=tokensInRbiValut.getText();
		System.out.println("Before Indnet creation tokens count in RBI vault :"+ tokeninRBIvault1 );
	}
	
	public void AfterIndnetTokensCount() throws InterruptedException
	{
		Thread.sleep(2000);
		 tokenscreated2=tokensCreated.getText();
		System.out.println("After Indnet creation created tokens count :"+ tokenscreated2);
		Thread.sleep(2000);
		 tokeninRBIvault2=tokensInRbiValut.getText();
		System.out.println("After Indnet creation tokens count in RBI vault :"+ tokeninRBIvault2);
	}
	
	public void compareIndnetProcessed()
	{
		long l1 = Long.parseLong(tokeninRBIvault2);
		long l2 = Long.parseLong(tokeninRBIvault1);
		long l3 = Long.parseLong(IndentMaker_CreateIndent.TokensCount);
		long value=l1-l2;	
		
		if(l3==value)
		{
			System.out.println(value +" Indnet Token are updated successfully in RBI DB");
		}
		else
		{
			System.out.println("Indent Token are  not updated successfully with :"+value);

		}
		
	}
	public void compareIndnetReject()
	{
		long l1 = Long.parseLong(tokeninRBIvault2);
		long l2 = Long.parseLong(tokeninRBIvault1);
//		long l3 = Long.parseLong(IndentMaker_CreateIndent.TokensCount);
		long value=l1-l2;	
//		System.out.println(value);
		if(0==value)
		{
			System.out.println("Indnet Token are not updated in DB due to indnet rejection");
		}
		else
		{
			System.out.println("Indnet Token are updated successfully with :"+value);

		}
	}
	
	
	public void BeforeIssuanceTokensCount() throws InterruptedException
	{
		Thread.sleep(2000);
//		 tokenscreated1=tokensCreated.getText();
//		System.out.println("Before Indnet creation created tokens count :"+ tokenscreated1);
//		Thread.sleep(2000);
		 tokeninRBIvault1=tokensInRbiValut.getText();
		System.out.println("Before Issuance Processed tokens count in RBI vault :"+ tokeninRBIvault1 );
	}
	
	public void  AfterIssuanceTokensCount() throws InterruptedException
	{
		Thread.sleep(2000);
//		 tokenscreated2=tokensCreated.getText();
//		System.out.println("After Indnet creation created tokens count :"+ tokenscreated2);
//		Thread.sleep(2000);
		 tokeninRBIvault2=tokensInRbiValut.getText();
		System.out.println("After Issuance Processed tokens count in RBI vault :"+ tokeninRBIvault2);
	}
	
	
	public void compareIssunaceProcessed()
	{
		long l1 = Long.parseLong(tokeninRBIvault2);
		long l2 = Long.parseLong(tokeninRBIvault1);
		long l3 = Long.parseLong(IssuanceMaker.TokensCount);
		System.out.println(l3);
		long value=l2-l1;	
		
		if(l3==value)
		{
			System.out.println(value +" Issuance Token are Deleted successfully in RBI DB" );
		}
		else
		{
			System.out.println(value + " Issuance Token are not Deleted in RBI DB");

		}
	}
	
	public void compareIssunaceReject()
	{
		long l1 = Long.parseLong(tokeninRBIvault2);
		long l2 = Long.parseLong(tokeninRBIvault1);
		long l3 = Long.parseLong(IssuanceMaker.TokensCount);
		System.out.println(l3);
		long value=l2-l1;	
		
		if(0==value)
		{
			System.out.println("Issuance Request Rejected So Token are not Deleted in RBI DB" );
		}
		else
		{
			System.out.println("Issuance Token are Deleted in RBI DB with :"+value);
		}
	}
	
}
