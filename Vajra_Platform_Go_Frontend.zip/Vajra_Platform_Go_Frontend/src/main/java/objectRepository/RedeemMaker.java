package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.JavaUtility;
import genericUtilities.WebDriverUtility;

public class RedeemMaker {
	WebDriverUtility wUtil = new WebDriverUtility();
	JavaUtility jUtil = new JavaUtility();

	public RedeemMaker(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='head']/div/button")
	WebElement requestRedeemBtn;

	@FindBy(xpath = "//select[@formcontrolname='denomination']")
	private WebElement selectDenominationEdt;

	@FindBy(xpath = "//*[@id='inputboxIssuance']")
	private WebElement quantityEdt;

	@FindBy(xpath = "//*[@id='firstRow']/td[4]/button")
	private WebElement plusBtn;

	@FindBy(xpath = "//*[@id='remark']")
	private WebElement makerRemarksEdt;

	@FindBy(xpath = "//b[text()='SUBMIT']")
	private WebElement submitBtn;

	@FindBy(xpath = "//button[@id='draft-btn']")
	private WebElement saveAsDraftBtn;

	@FindBy(xpath = "//a[text()='Drafts']")
	private WebElement draftBtn;
	
	@FindBy(xpath = "(//a[@class='viewDetails'])[1]")
	private WebElement draftRedeemId;
	
	@FindBy(xpath = "//button[text()=' DISCARD ']")
	private WebElement discardDraftIssuance;
	
	@FindBy(xpath = "//b[text()='SUBMIT']")
	 private WebElement submitDraftRedeem;
	
	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;
	
	public WebElement getRequestIssuanceBtn() {
		return requestRedeemBtn;
	}

	public WebElement getSelectDenominationEdt() {
		return selectDenominationEdt;
	}

	public WebElement getQuantityEdt() {
		return quantityEdt;
	}

	public WebElement getPlusBtn() {
		return plusBtn;
	}

	public WebElement getMakerRemarksEdt() {
		return makerRemarksEdt;
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public WebElement getSaveAsDraftBtn() {
		return saveAsDraftBtn;
	}

	public WebElement draftBtn() {
		return draftBtn;
	}
	public WebElement draftIssuanceId() {
		return draftRedeemId;
	}

	public WebElement discardDraftIssuance() {
		return discardDraftIssuance;
	}
	
	public WebElement submitDraftIssuance() {
		return submitDraftRedeem;
	}
	
	public WebElement getIdMsg() {
		return idMsg;
	}
	
	public void createRedeemBySubmit() throws InterruptedException {
		requestRedeemBtn.click();
		Thread.sleep(2000);
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("OK" + jUtil.getRandomNumber());
		submitBtn.click();
		String msgId=idMsg.getText();
		System.out.println(msgId);
		System.out.println("Issuance Request Submit Successfully");
	}

	public void createRedeemByDraftAndDiscard() {
		requestRedeemBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("OK" + jUtil.getRandomNumber());
		saveAsDraftBtn.click();
		String msgId=idMsg.getText();
		System.out.println(msgId);
		draftBtn.click();
		draftRedeemId.click();
		discardDraftIssuance.click();
		String msgId2=idMsg.getText();
		System.out.println(msgId2);
		System.out.println("Draft Issuance Request Discard Successfully");
	}
	public void createRedeemByDraftAndSubmit() throws InterruptedException {
		requestRedeemBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("OK" + jUtil.getRandomNumber());
		saveAsDraftBtn.click();
		String msgId=idMsg.getText();
		System.out.println(msgId);
		draftBtn.click();
		Thread.sleep(2000);
		draftRedeemId.click();
		submitDraftRedeem.click();
		String msgId2=idMsg.getText();
		System.out.println(msgId2);
		
		System.out.println("Draft Issuance Request Submit Successfully");
	}
}
