package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.JavaUtility;

public class IssuanceApprover {
	JavaUtility jUtil = new JavaUtility();

	public IssuanceApprover(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//td[@class='c-table__cell'])[1]")
	private WebElement approveIssaunceId;
	
//	@FindBy(xpath = "/html/body/app-root/app-common-layout/div/main/div/div/div/app-token-issuance-request-list/div/div[2]/div/table/tbody/tr[1]/td[1]")
//	private WebElement approveIssaunceId;
	
	@FindBy(xpath = "//textarea[@id='remark']")
	private WebElement remarksEdt;
	
	
//	@FindBy(xpath = "//*[@id='remark']")
//	private WebElement remarksEdt;

	@FindBy(xpath = "//button[text()=' APPROVE ']")
	private WebElement approveBtn;

	@FindBy(xpath = "//button[text()=' REJECT ']")
	private WebElement rejectBtn;

	@FindBy(xpath = "//button[@id='yes-button']")
	private WebElement yesBtn;

	@FindBy(xpath = "//button[@id='no-button']")
	private WebElement noBtn;
	
	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;

	public WebElement getApproveIssaunceId() {
		return approveIssaunceId;
	}

	public WebElement getRemarksEdt() {
		return remarksEdt;
	}

	public WebElement getApproveBtn() {
		return approveBtn;
	}

	public WebElement getRejectBtn() {
		return rejectBtn;
	}

	public WebElement getYesBtn() {
		return yesBtn;
	}

	public WebElement getNoBtn() {
		return noBtn;
	}

	public WebElement getIdMsg() {
		return idMsg;
	}

	public void approveIssuance() throws InterruptedException {
		Thread.sleep(2000);
		approveIssaunceId.click();;
		Thread.sleep(2000);
		remarksEdt.sendKeys("APPROVE " + jUtil.getRandomNumber());
		approveBtn.click();
		yesBtn.click();
//		Thread.sleep(1000);
//		String msgId = idMsg.getText();
//		System.out.println(msgId);
	
		System.out.println("RBI Issuance Approver Approved Successfully");
	}

	public void rejectIssuance() throws Throwable {
		Thread.sleep(2000);
		approveIssaunceId.click();
		remarksEdt.sendKeys("APPROVE " + jUtil.getRandomNumber());
		rejectBtn.click();
		yesBtn.click();
		Thread.sleep(1000);
		String msgId = idMsg.getText();
		System.out.println(msgId);
		
		System.out.println("RBI Issuance Approver rejected Successfully");
	}
}
