package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.JavaUtility;

public class IssuanceChecker {
	JavaUtility jUtil = new JavaUtility();

	public IssuanceChecker(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//a[@class='viewDetails'])[1]")
	private WebElement checkerApproveIssuanceId;

	@FindBy(xpath = "//*[@id='remark']")
	private WebElement remarksEdt;

	@FindBy(xpath = "//button[text()=' APPROVE ']")
	private WebElement approveBtn;

	@FindBy(xpath = "//button[text()=' REJECT ']")
	private WebElement rejectBtn;

	@FindBy(xpath = "//button[@id='yes-button']")
	private WebElement yesBtn;

	@FindBy(xpath = "//button[@id='no-button']")
	private WebElement noBtn;
	
	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;

	public WebElement getCheckerApproveIssuanceId() {
		return checkerApproveIssuanceId;
	}

	public WebElement getRemarksEdt() {
		return remarksEdt;
	}

	public WebElement getApproveBtn() {
		return approveBtn;
	}

	public WebElement getRejectBtn() {
		return rejectBtn;
	}

	public WebElement getYesBtn() {
		return yesBtn;
	}

	public WebElement getNoBtn() {
		return noBtn;
	}
	
	public WebElement getIdMsg() {
		return idMsg;
	}

	public void checkerApproveIssuance() throws InterruptedException {
		checkerApproveIssuanceId.click();
		Thread.sleep(3000);
		remarksEdt.sendKeys("APPROVE " + jUtil.getRandomNumber());
		approveBtn.click();
		yesBtn.click();
//		Thread.sleep(3000);
//		String msgId=idMsg.getText();
//		System.out.println(msgId);
		System.out.println("Issuance Checker Approved successfully");
	}

	public void checkerRejectIssuance() throws InterruptedException {
		checkerApproveIssuanceId.click();
		remarksEdt.sendKeys("REJECT " + jUtil.getRandomNumber());
		rejectBtn.click();
		yesBtn.click();
		Thread.sleep(1000);
		String msgId=idMsg.getText();
		System.out.println(msgId);
		System.out.println("Issuance Checker Rejected successfully");
	}
}
