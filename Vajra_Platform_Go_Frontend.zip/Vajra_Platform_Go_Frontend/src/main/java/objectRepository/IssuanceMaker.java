package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.JavaUtility;
import genericUtilities.WebDriverUtility;

public class IssuanceMaker {
	public static String TokensCount;
	WebDriverUtility wUtil = new WebDriverUtility();
	JavaUtility jUtil = new JavaUtility();

	public IssuanceMaker(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='head']/div/button")
	WebElement requestIssuanceBtn;

	@FindBy(xpath = "//select[@formcontrolname='denomination']")
	private WebElement selectDenominationEdt;

	@FindBy(xpath = "//*[@id='inputboxIssuance']")
	private WebElement quantityEdt;

	@FindBy(xpath = "//*[@id='firstRow']/td[4]/button")
	private WebElement plusBtn;

	@FindBy(xpath = "//*[@id='remark']")
	private WebElement makerRemarksEdt;

	@FindBy(xpath = "//button[text()=' SUBMIT ']")
	private WebElement submitBtn;

	
//	@FindBy(xpath = "//*[@id='mat-dialog-1']/app-token-issuance-request/div/div/div/div/form/div[3]/div/div/button[1]")
//	private WebElement submitBtn;

	@FindBy(xpath = "//button[@id='draft-btn']")
	private WebElement saveAsDraftBtn;

//	@FindBy(xpath = "//*[@id='mat-dialog-1']/app-token-issuance-request/div/div/div/div/form/div[3]/div/div/button[2]")
//	private WebElement saveAsDraftBtn;

	@FindBy(xpath = "//a[text()='Drafts']")
	private WebElement draftBtn;
	
	@FindBy(xpath = "(//a[@class='viewDetails'])[1]")
	private WebElement draftIssuanceId;
	
	@FindBy(xpath = "//button[text()=' DISCARD ']")
	private WebElement discardDraftIssuance;
	
	@FindBy(xpath = "//button[text()=' SUBMIT ']")
	 private WebElement submitDraftIssuance;
	
	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;
	
	
	@FindBy(xpath = "//*[@id='mat-dialog-0']/app-token-issuance-request/div/div/div/div/form/div[1]/div/app-all-denomination-form/div/table/tfoot/tr/td[2]/strong")
    private WebElement totalTokenCount;
	
	
	public WebElement getTotalTokenCount() {
		return totalTokenCount;
	}
	
	public WebElement getRequestIssuanceBtn() {
		return requestIssuanceBtn;
	}

	public WebElement getSelectDenominationEdt() {
		return selectDenominationEdt;
	}

	public WebElement getQuantityEdt() {
		return quantityEdt;
	}

	public WebElement getPlusBtn() {
		return plusBtn;
	}

	public WebElement getMakerRemarksEdt() {
		return makerRemarksEdt;
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public WebElement getSaveAsDraftBtn() {
		return saveAsDraftBtn;
	}

	public WebElement draftBtn() {
		return draftBtn;
	}
	public WebElement draftIssuanceId() {
		return draftIssuanceId;
	}

	public WebElement discardDraftIssuance() {
		return discardDraftIssuance;
	}
	
	public WebElement submitDraftIssuance() {
		return submitDraftIssuance;
	}
	
	public WebElement getIdMsg() {
		return idMsg;
	}
	
	public void createIssuanceBySubmit() throws InterruptedException {
		requestIssuanceBtn.click();
		Thread.sleep(2000);
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		
	
		
		TokensCount = totalTokenCount.getText();
		System.out.println("Tokens requested in issuance request is "+ TokensCount);
		
		
		
		makerRemarksEdt.sendKeys("OK" + jUtil.getRandomNumber());
		Thread.sleep(1000);
		submitBtn.click();
		Thread.sleep(1000);
		String msgId=idMsg.getText();
		System.out.println(msgId);
		System.out.println("Issuance Request Submit Successfully");
	}

	public void createIssuanceByDraftAndDiscard() throws InterruptedException {
		requestIssuanceBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("OK" + jUtil.getRandomNumber());
		saveAsDraftBtn.click();
		Thread.sleep(3000);
		String msgId=idMsg.getText();
		System.out.println(msgId);
		Thread.sleep(2000);
		draftBtn.click();
		Thread.sleep(1000);
		draftIssuanceId.click();
		Thread.sleep(1000);
		discardDraftIssuance.click();
		Thread.sleep(1000);
		String msgId2=idMsg.getText();
		System.out.println(msgId2);
		System.out.println("Draft Issuance Request Discard Successfully");
	}
	public void createIssuanceByDraftAndSubmit() throws InterruptedException {
		requestIssuanceBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("OK" + jUtil.getRandomNumber());
		saveAsDraftBtn.click();
		Thread.sleep(2000);
		String msgId=idMsg.getText();
		System.out.println(msgId);
		draftBtn.click();
		Thread.sleep(1000);
		draftIssuanceId.click();
		Thread.sleep(2000);
		submitDraftIssuance.click();
		Thread.sleep(1000);
		String msgId2=idMsg.getText();
		System.out.println(msgId2);
		
		System.out.println("Draft Issuance Request Submit Successfully");
	}
}
