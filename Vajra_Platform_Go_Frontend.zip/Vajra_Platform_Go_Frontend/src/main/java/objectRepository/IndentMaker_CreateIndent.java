package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import genericUtilities.JavaUtility;
import genericUtilities.WebDriverUtility;
import groovy.transform.Final;

public class IndentMaker_CreateIndent {
	
	
	public static String TokensCount;
	WebDriverUtility wUtil = new WebDriverUtility();
	JavaUtility jUtil = new JavaUtility();

// Initilization
	
	public IndentMaker_CreateIndent(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
//  Decleration
	
	@FindBy(xpath = "//*[@id='token-summary-table']/thead/tr[2]/td[1]")
	private WebElement tokensCreated;
	
	@FindBy(xpath = "//*[@id='token-summary-table']/thead/tr[6]/td[1]")
	private WebElement tokensInRbiValut;

	@FindBy(xpath = "//button[@class='c-btn c-btn--info ng-star-inserted']")
	private WebElement createIndentBtn;

	@FindBy(xpath = "//select[@formcontrolname='denomination']")
	private WebElement selectDenominationEdt;

	@FindBy(xpath = "//*[@id='inputboxIssuance']")
	private WebElement quantityEdt;

	@FindBy(xpath = "//*[@id='firstRow']/td[4]/button")
	private WebElement plusBtn;

	@FindBy(xpath = "//*[@id='remark']")
	private WebElement makerRemarksEdt;

//	@FindBy(xpath = "//b[text()='SUBMIT']")
//	private WebElement submitBtn;
	
	
	@FindBy(xpath = "//*[@id='outer']/div/div/div/form/div[3]/div/div/button[1]")
	private WebElement submitBtn;

//	@FindBy(xpath = "//b[text()='SAVE AS DRAFT']")
//	private WebElement saveAsDraftBtn;
	
	@FindBy(xpath = "//*[@id='draft-btn']")
	private WebElement saveAsDraftBtn;
	

	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;

	@FindBy(xpath = "//*[@id='outer']/button/span")
	private WebElement successBtn;

	@FindBy(xpath = "//a[text()='Drafts']")
	private WebElement draftBtn;
	
	@FindBy(xpath = "(//a[@class='viewDetails'])[1]")
	private WebElement draftIndnetId;
	
	@FindBy(xpath = "//button[text()=' DISCARD ']")
	private WebElement discardDraftIndent;
	
	@FindBy(xpath = "//*[@id='outer']/div/div/div/form/div[3]/div/div/button[1]")
    private WebElement submitDraftIndent;
	
	@FindBy(xpath = "//*[@id='outer']/div/div/div/form/div[1]/div/app-all-denomination-form/div/table/tfoot/tr/td[2]/strong")
    private WebElement totalTokenCount;
	
	
	public WebElement getTotalTokenCount() {
		return totalTokenCount;
	}
	
	
	public WebElement getTokensCreated() {
		return tokensCreated;
	}
	public WebElement getTokensInRbiValut() {
		return tokensInRbiValut;
	}

	public WebElement getCreateIndentBtn() {
		return createIndentBtn;
	}

	public WebElement getSelectDenominationEdt() {
		return selectDenominationEdt;
	}

	public WebElement getQuantityEdt() {
		return quantityEdt;
	}

	public WebElement getPlusBtn() {
		return plusBtn;
	}

	public WebElement getRemarksEdt() {
		return makerRemarksEdt;
	}

	public WebElement getSumitBtn() {
		return submitBtn;
	}

	public WebElement getSaveAsDraftBtn() {
		return saveAsDraftBtn;
	}

	public WebElement getIdMsg() {
		return idMsg;
	}

	public WebElement getSuccessBtn() {
		return successBtn;
	}

	public WebElement draftBtn() {
		return draftBtn;
	}

	public WebElement draftIndnetId()
	{
		return draftIndnetId;
	}
	
	public WebElement discarddraftindent()
	{
		return discardDraftIndent;
	}
	public WebElement submitDraftIndent() {
		return submitDraftIndent;
	}
	
	public void createIndentRequestBySubmit() throws InterruptedException {
		createIndentBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
//		System.out.println(jUtil.getRandomNumber());
		plusBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		
		
		TokensCount = totalTokenCount.getText();
		System.out.println("Token requested in Indnet request is "+ TokensCount);
		
		
		makerRemarksEdt.sendKeys("Create " + jUtil.getRandomNumber());
		submitBtn.click();
		Thread.sleep(3000);
		String IndentId = idMsg.getText();
//		System.out.println(IndentId);
		Thread.sleep(2000);
		successBtn.click();
        System.out.println("Successfully Submit "+IndentId);
	}

	public void createIndentRequestByDraftAndDiscard() throws InterruptedException {
		createIndentBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("Create " + jUtil.getRandomNumber());
		saveAsDraftBtn.click();
		Thread.sleep(3000);
		String value = idMsg.getText();
		System.out.println(value);
		Thread.sleep(2000);
		successBtn.click();
		Thread.sleep(1000);
		draftBtn.click();
		Thread.sleep(2000);
		draftIndnetId.click();
		Thread.sleep(1000);
		discardDraftIndent.click();
		Thread.sleep(4000);
//		String value1 = idMsg.getText();
//		System.out.println(value1);
		String discardDraftIndentId = idMsg.getText();
		System.out.println("Successfully Draft Indent Discarded "+discardDraftIndentId);
	}
	public void createIndentRequestByDraftAndSubmit() throws InterruptedException {
		createIndentBtn.click();
		wUtil.dropDownByIndex(selectDenominationEdt);
		quantityEdt.sendKeys(String.valueOf(jUtil.getRandomNumber()));
		plusBtn.click();
		makerRemarksEdt.sendKeys("Create " + jUtil.getRandomNumber());
		
		
		TokensCount = totalTokenCount.getText();
		System.out.println("Token requested in Indnet request is "+ TokensCount);
		
		
		saveAsDraftBtn.click();
		Thread.sleep(3000);
		String value = idMsg.getText();
		System.out.println(value);
		successBtn.click();
		draftBtn.click();
		Thread.sleep(2000);
		draftIndnetId.click();
		Thread.sleep(2000);
		submitDraftIndent.click();
		Thread.sleep(4000);
		String submitDraftIndentId = idMsg.getText();
		System.out.println("Successfully Submit Draft "+submitDraftIndentId);
		successBtn.click();
	}
}
