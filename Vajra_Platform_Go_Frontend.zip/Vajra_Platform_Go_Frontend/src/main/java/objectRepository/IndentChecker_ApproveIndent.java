package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import genericUtilities.JavaUtility;

public class IndentChecker_ApproveIndent {
	
JavaUtility jUtil=new JavaUtility();
//	 
	public IndentChecker_ApproveIndent(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
//	Decleration
	
	@FindBy(xpath = "(//a[@class='viewDetails'])[1]")
	private WebElement approveIndentIdReq;
	
	@FindBy(xpath = "//*[@id='remark']")
	private WebElement chekerRemarksEdt;
	
	@FindBy(xpath = "//*[@id='approve-button']")
	private WebElement approveBtn;
	
	@FindBy(xpath = "//button[text()=' REJECT ']")
	private WebElement rejectBtn;
	
	@FindBy(xpath = "//*[@id='yes-button']")
	private WebElement yesBtn;
	
	@FindBy(xpath ="//*[@id='no-button']")
	private WebElement noBtn;
	
	@FindBy(xpath = "//div[@id='toast-container']")
	private WebElement idMsg;

//	Utilization 
	
	public WebElement getApproveIndentIdReq() {
		return approveIndentIdReq;
	}

	public WebElement getChekerRemarksEdt() {
		return chekerRemarksEdt;
	}

	public WebElement getApproveBtn() {
		return approveBtn;
	}
	
	public WebElement getYesBtn() {
		return yesBtn;
	}
	
	public WebElement noBtn() {
		return noBtn;
	}
	public WebElement rejectBtn()
	{
		return rejectBtn;
	}
	
	public WebElement getIdMsg() {
		return idMsg;
	}

	public void approveIndentRequest() throws InterruptedException {
//		Thread.sleep(2000);
		approveIndentIdReq.click();
		chekerRemarksEdt.sendKeys("APPROVE"+jUtil.getRandomNumber());
		approveBtn.click();
		Thread.sleep(1000);
		yesBtn.click();
		Thread.sleep(4000);
		String approvedIndentId = idMsg.getText();
		System.out.println(approvedIndentId);
		
		System.out.println("cheker Approved successfully");
	}
	
	public void rejectIndentRequest() throws InterruptedException {
		Thread.sleep(1000);
		approveIndentIdReq.click();
		chekerRemarksEdt.sendKeys("REJECT"+jUtil.getRandomNumber());
		rejectBtn.click();
		yesBtn.click();
		Thread.sleep(4000);
		String rejectIndentId = idMsg.getText();
		System.out.println(rejectIndentId);
		
		System.out.println("cheker Rejected successfully");
		
	}
}
