package objectRepository;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import genericUtilities.JavaUtility;
import genericUtilities.PropertyFileUtility;
import genericUtilities.WebDriverUtility;

public class BaseClassBySBI {
	public PropertyFileUtility pUtil = new PropertyFileUtility();
	public WebDriverUtility wUtil = new WebDriverUtility();
	public JavaUtility jUtil = new JavaUtility();
	public WebDriver driver = null;

	@BeforeClass(groups = {"smokeSuite"})
	public void bcConfig() throws IOException {
		String SBI_URL=pUtil.readDataFromPropertyFile("sbi_url_2");
		String BROWSER = pUtil.readDataFromPropertyFile("browser");

		if (BROWSER.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
			driver = new ChromeDriver();
			System.out.println("===  Chrome Browser Launched Successfully  ==");
		} else if (BROWSER.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
			System.out.println("===  Edge Browser Launched Successfully  ==");
		}

		wUtil.maximiseWindow(driver);
		wUtil.waitForElementToLoadInDom(driver);
		driver.navigate().to(SBI_URL);
	}

	@BeforeMethod(groups = {"smokeSuite"})
	public void bmConfig() throws IOException, InterruptedException {
		String USERNAME = pUtil.readDataFromPropertyFile("usernamesbi");
		String PASSWORD = pUtil.readDataFromPropertyFile("password");
		String OTP=pUtil.readDataFromPropertyFile("otp");
		LoginPage lp = new LoginPage(driver);
		lp.indentMakerLogin(USERNAME, PASSWORD, OTP);
	}

	@AfterMethod(groups = {"smokeSuite"})
	public void amConfig() throws InterruptedException {
		HomePage hp = new HomePage(driver);
		hp.logout();
		System.out.println("Logout Successfully");
	}

	@AfterClass(groups = {"smokeSuite"})
	public void acConfig() {
		driver.quit();
	}
}
