package Login;

import org.testng.annotations.Test;

public class Get_Session {
@Test
public void getSession() {
	System.out.println("demo");
}
}
