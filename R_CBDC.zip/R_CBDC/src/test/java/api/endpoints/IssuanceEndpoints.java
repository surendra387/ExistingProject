package api.endpoints;
import static io.restassured.RestAssured.given;

import java.util.Random;

import api.payload.ApproveIssuanceData;
import api.payload.DiscardIssuanceData;
import api.payload.IssuanceData;
import api.payload.QcymrespData;
import api.payload.RbiIssuanceApproveData;
import api.payload.SubmitDraftIssuanceData;
import api.test.CreateIssuance;
import api.test.RBI_LoginApi;
import api.test.SBI_LoginApi;
import io.restassured.response.Response;

public class IssuanceEndpoints extends SBI_LoginApi{
	
public static Response draftIssuance(IssuanceData requestBody)
{
 Response response = given()
.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
.body(requestBody)
.when()
.post(Routes.draft_issuance);
 return response;
}
public static Response createIssuance(IssuanceData requestBody)
{
	Response response = given()
	.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.body(requestBody)
	
	.when()
//	.post("http://localhost:9003/rbb-sbi/sbi/api/v1/token/issuance/");
	.post(Routes.create_issuance);
	return response;
}
public static Response updateDraftIssuance(IssuanceData requestBody)
{
	
Response response = given()
	.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.pathParam("Id", CreateIssuance.Data1)
	.body(requestBody)
	.when()
	.post(Routes.update_draft_issuance);
	return response;
}
public static Response submitDraftIssuance(SubmitDraftIssuanceData submitIssuanceBody)
{
Response response = given()
    .headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.body(submitIssuanceBody)
	.pathParam("Id", CreateIssuance.Data1)
	.when()
	.post(Routes.submit_draft_issuance);
	return response;
	
}
public static Response discardIssuance(DiscardIssuanceData discardIssuanceBody)
{
	Response response = given()
	.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.pathParam("Id", CreateIssuance.Data1)
	.body(discardIssuanceBody)
	.when()
	.post(Routes.discard_draft_issuance);
	return response;
	
}
public static Response approveIssuance(ApproveIssuanceData approveIssuanceBody)
{
	Random r=new Random();
	String[] id= {CreateIssuance.Data1,CreateIssuance.Data2};
    int randomIndex=r.nextInt(id.length);
    String ramdomValue=id[randomIndex]; 
   
    System.out.println("random values is:"+ramdomValue);
    
     Response response=	given()
	.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.body(approveIssuanceBody)
	.pathParam("Id", ramdomValue)
	.when()
	.post(Routes.checker_approve_issuance);
	 return response ;
}
//public static Response RBIIssuanceApprover(RbiIssuanceApproveData rbiapproveIssuanceBody)
//{
//Response response = given()
//	.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
//	.body(rbiapproveIssuanceBody)
//	.pathParam("Id",CreateIssuance.Data3)
//	.when()
//	.post(Routes.rbi_approve_issuance);
//return response;
//}
//public static Response QCYMrespTokendebit(QcymrespData xmlPayload)
//{
//	
//	Response response = given()
//	.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
//	.body(xmlPayload.getXmlPayload())
//	.when()
//	.post("http://localhost:9002/rrb/api/retail-token-system/v1/respToken");
//	return response;
//	
//}
//public static Response QCYMrespTokendebit(String xmlPayload) {
//	// TODO Auto-generated method stub
//	return null;
//}
}
