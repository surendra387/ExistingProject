package api.endpoints;

import static io.restassured.RestAssured.given;

import java.util.Random;

import org.testng.annotations.Test;

import api.payload.ApproveIndentData;
import api.payload.DiscardIndentData;
import api.payload.IndentData;
import api.payload.RejectIndentData;
import api.payload.submitDraftIndentData;
import api.test.CreteIndent;
import api.test.RBI_LoginApi;
import io.restassured.response.Response;
public class IndentEndpoints extends RBI_LoginApi{   
	public static Response createDraftIndent(IndentData requestBody)
	{
		Response response=given()
				.request().body(requestBody.toString())
			.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
			.body(requestBody)
		.when()
			.post(Routes.draft_indent);
			
		return response;
	}
	public static Response createIndent(IndentData requestBody) {
		 Response response = given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.body(requestBody)
		.when()
		.post(Routes.create_indent);
		 return response;
	}
	public static Response approveIndent(ApproveIndentData ApproveIndentBody) {

		 Random r=new Random();
		 String[]id= {CreteIndent.Data1,CreteIndent.Data2};
		 int randomIndex=r.nextInt(id.length);
	     String randomValue=id[randomIndex];
	    System.out.println("random values is:"+randomValue);
	    Response response=	given()
				 .headers("Authorization", "Bearer "+Bearer_Token_Rbi)
				 .pathParam("Id",randomValue )
		         .body(ApproveIndentBody)
		        .when()
		        .post(Routes.approve_indent);
		         return response;
		
	}
	@Test
	public static Response updateDraftIndent(IndentData requestBody) {
		
		 Response response=	given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.body(requestBody)
		.pathParam("Id", CreteIndent.Data1)
		.when()
		
		.post(Routes.update_draft_indent);
		
		return response;
	}
	public static Response submitDraftIndent(submitDraftIndentData submitDraftBody) {
		
		 Response response=	given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.body(submitDraftBody)
		.pathParam("Id", CreteIndent.Data1)
		.when()
		.post(Routes.submit_draft_indent);
		return response;
	}
	public static Response discardIndent(DiscardIndentData discardIndentBody) {
		Response response = given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.body(discardIndentBody)
		.pathParam("Id",CreteIndent.Data1 )
		.when()
		.post(Routes.discard_draft_indent);
		return response;
	}
	public static Response rejectIndent(RejectIndentData  rejectIndentBody) {
		 Random r=new Random();
		 String[]id= {CreteIndent.Data1,CreteIndent.Data2};
		 int randomIndex=r.nextInt(id.length);
	     String randomValue=id[randomIndex];
	    System.out.println("random values is:"+randomValue);
		Response response = given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.body(rejectIndentBody)
		.pathParam("Id", randomValue)
		.when()
		.post(Routes.reject_indent);
		return response;
	}
	public static Response getPendingApproval() {
	Response response=	given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.queryParam("status", "PENDING_APPROVAL")
//		.queryParam("limit",10)
		.when()
		.get(Routes.pending_approval);
	     return response;
	}
	public static void test() {
	
	}
	}


