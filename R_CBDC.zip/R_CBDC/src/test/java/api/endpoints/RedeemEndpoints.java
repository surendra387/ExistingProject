package api.endpoints;

import static io.restassured.RestAssured.given;

import api.payload.ApproveRedeemData;
import api.payload.RedeemData;
import api.test.SBI_LoginApi;
import io.restassured.response.Response;

public class RedeemEndpoints extends SBI_LoginApi {
public static Response createRedeem(RedeemData redeemData) {
Response response = given()
.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
.body(redeemData)
.when()
//.post(Routes.create_redeem);
.post("http://localhost:9003/rbb-sbi/sbi/api/v1/token/redeem");
return response;
}
public static Response checkerApproveReddem(ApproveRedeemData approveredeemData) {
Response response = given()
	.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.body(approveredeemData)
	.when()
	.post(Routes.checker_approve_redeem);
	return response;
}
}

