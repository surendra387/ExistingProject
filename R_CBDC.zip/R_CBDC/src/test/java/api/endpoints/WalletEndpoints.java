package api.endpoints;
import static io.restassured.RestAssured.given;

import api.test.RBI_LoginApi;
import io.restassured.response.Response;
public class WalletEndpoints extends RBI_LoginApi{
public static Response createRBIWallet() {
	Response response = given()
	.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
	.when()
	.post(Routes.create_indent_wallet);
	return response;
}
public static Response getCreateRBIWallet()
{
	Response response = given()
	.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
	.when()
	.get(Routes.get_indent_wallet);
	return response;
}
}
