package api.endpoints;
import static io.restassured.RestAssured.given;

import api.test.RBI_LoginApi;
import api.test.SBI_LoginApi;
import io.restassured.response.Response;
public class SBIWalletEndpoints extends SBI_LoginApi{
public static Response createIssunaceWallet() {
     Response response=given()
	.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
	.when()
	.post(Routes.create_issuance_wallet);
	return response;
}
public static Response getcreateIssunaceWallet() {
	         Response response=given()
			.headers("Authorization", "Bearer "+Bearer_Token_Sbi)
			.when()
			.get(Routes.create_issuance_wallet);
			return response;
}


}
