package api.endpoints;

import java.util.Random;
import static io.restassured.RestAssured.given;
import api.payload.ApproveIssuanceData;
import api.payload.RbiIssuanceApproveData;
import api.test.CreateIssuance;
import api.test.RBI_LoginApi;
import io.restassured.response.Response;

public class RBIIssuanceApproverEndpoints extends RBI_LoginApi {

	public static Response RBIIssuanceApprover(RbiIssuanceApproveData rbiapproveIssuanceBody)
	{
	Response response = given()
		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
		.body(rbiapproveIssuanceBody)
		.pathParam("Id",CreateIssuance.Data3)
		.when()
		.post(Routes.rbi_approve_issuance);
	return response;
	}
//	public static Response QCYMrespTokendebit(QcymrespData xmlPayload)
//	{
//		
//		Response response = given()
//		.headers("Authorization", "Bearer "+Bearer_Token_Rbi)
//		.body(xmlPayload.getXmlPayload())
//		.when()
//		.post("http://localhost:9002/rrb/api/retail-token-system/v1/respToken");
//		return response;
////		
//	}
//	public static Response QCYMrespTokendebit(String xmlPayload) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}
