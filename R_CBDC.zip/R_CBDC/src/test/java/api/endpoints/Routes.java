package api.endpoints;

public class Routes {
	
	public static String rbi_base_url="http://localhost:9002/rrb/api/retail-token-system/v1";
	
	public static String sbi_base_url="http://localhost:9003/rbb-sbi/sbi/api/v1";

	
	public static String icici_base_url="http://localhost:9005/rbb-icici/icici/api/v1";
    //Login
	
	public static String rbi_get_Session=rbi_base_url+"/auth/session";
	
	public static String rbi_login_User=rbi_base_url+"/auth/login";
	
	public static String sbi_get_Session=sbi_base_url+"/auth/session";
	public static String sbi_login_User=sbi_base_url+"/auth/login";
	//IndentMaker

	public static String draft_indent=rbi_base_url+"/indent/";
	
	public static String create_indent=rbi_base_url+"/indent/";
	
	public static String update_draft_indent=rbi_base_url+"/indent/{Id}";
	
	public static String submit_draft_indent=rbi_base_url+"/indent/{Id}";
	
	public static String discard_draft_indent=rbi_base_url+"/indent/{Id}";
	
	public static String pending_approval=rbi_base_url+"/indent/";
	
	//IndentChecker
	
	public static String approve_indent=rbi_base_url+"/indent/{Id}";
	
	public static String reject_indent=rbi_base_url+"/indent/{Id}";
	
	public static String list_indent=rbi_base_url+"/indent/";
	
	public static String indent_By_Id_url=rbi_base_url+"/indent/{Id}";
	
	//wallets
	public static String create_indent_wallet=rbi_base_url+"/wallet/";
	
	public static String get_indent_wallet=rbi_base_url+"/wallet/";
	
	public static String create_issuance_wallet=sbi_base_url+"/wallet/";
	
	public static String get_issuance_wallet=sbi_base_url+"/wallet/";
	
	public static String create_icici_wallet=icici_base_url+"/wallet/";
	
	
//Issuance Maker

	public static String draft_issuance=sbi_base_url+"/token/issuance/";
	
	public static String create_issuance=sbi_base_url+"/token/issuance/";
	
	public static String update_draft_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	public static String submit_draft_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	public static String discard_draft_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	//Issuance Checker
	
	public static String checker_approve_issuance=sbi_base_url+"/token/issuance/{Id}";
	
	//RBI Issuance Approver
	
	public static String rbi_approve_issuance=rbi_base_url+"/token/issuance/{Id}";
	
	public static String Qcym_respToken_debit=rbi_base_url+"/respToken";
	
	// Redeem 
	public static String create_redeem=sbi_base_url+"/token/redeem";
	
	public static String checker_approve_redeem=sbi_base_url+"/token/redeem/{{Id}}";
}
