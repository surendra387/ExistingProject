package api.endpoints;

import static io.restassured.RestAssured.given;

import api.payload.LoginUserData;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.response.Response;

public class Login {

	public static Response gettSession() {
		Response response = given()

				.when()
//	.post(Routes.rbi_get_Session);
				.post("http://localhost:9002/rrb/api/retail-token-system/v1/auth/session");
		return response;
	}

	public static Response loginUser(LoginUserData requestBody) {
		Response response = given().contentType(ContentType.JSON).request().body(requestBody.toString())
				.body(requestBody)

				.when().post(Routes.rbi_login_User);
		return response;
	}

	public static Response gettSessionBySbi() {
		Response response = given()

				.when().post(Routes.sbi_get_Session);
//				.post("http://localhost:9002/rrb/api/retail-token-system/v1/auth/session");
		return response;
	}

	public static Response loginUserBySbi(LoginUserData requestBody) {
		Response response = given().contentType(ContentType.JSON).request().body(requestBody.toString())
				.body(requestBody)

				.when().post(Routes.sbi_login_User);
		return response;
	}
}
