package api.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class propertyFileUtility {
	/**
	 * This method will read the data from propertyFile.
	 * @throws IOException 
	 */
public String readDataFromPropertyFile(String key) throws IOException {
	FileInputStream fis=new FileInputStream("/home/pasala.surendra_oli@npci.org.in/Desktop/vajra_Platform_Go_Apis/R_CBDC/src/test/java/api/utilities/UserCredentials.properties");
	Properties p=new Properties();
	p.load(fis);
	String value=p.getProperty(key);
	return value;
}
}