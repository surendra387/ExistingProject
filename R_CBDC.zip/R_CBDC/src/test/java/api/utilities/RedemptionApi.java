package api.utilities;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class RedemptionApi {
	@Test
	public void redeem() {
		String Body = "<ns2:RespUpdateToken xmlns:token=\"http://npci.org/token/schema/\">\n"
				+ "    <Head ver=\"1.0\" ts=\"\" orgId=\"123456\" msgId=\"qwedfghbnzsdrr\"/>\n"
				+ "    <!-- The Response Details will be sent here. -->\n"
				+ "    <ResDetails type=\"CHECKREDEEM\">\n"
				+ "        <Resp reqMsgId=\"qwedfghbnzsdrq\" result=\"SUCCESS\" errCode=\"\" requestId=\"23O686751\">\n"
				+ "            <Tokens>\n"
				+ "                <Token id=\"ddf741ad58ab6d490e01e65607f92064492843da2afaed202ed18c0ae6a2de4a\"/>\n"
//				+ "                <Token id=\"000122542876f76fa1d538712236fde6454314475e4ee57bf22343c54b20697d\"/>\n"
//				+ "                <Token id=\"00075efa3c9671d359d653b3a2ba57beda0273bc9db0b02ac1e1e19ee12e0a2c\"/>\n"
//				+ "                <Token id=\"0007e8133299a9dd08101b0ac68fc6caed38db6fed489f112f2f3e442b98bbd3\"/>\n"
//				+ "                <Token id=\"000ad6de4fbb2a72e816514e193faa46f7681bb89e785754ef7d3d8e56407491\"/>\n"
//				+ "                <Token id=\"000b44bbab444b5501bc0ad0e6071333721e7e4f495eb0d26b2f90285443180f\"/>\n"
//				+ "                <Token id=\"000b62df92435f833047628e1dcfb6be2d0dfc4a23ce2158e8a20aaff0611356\"/>\n"
//				+ "                <Token id=\"000e6101cd58ec2055d380bf29aad509c830f3ed618a5b40bd86f8452348b519\"/>\n"
//				+ "                <Token id=\"000f8fe375e82e99138f7377b1ca1de8e931defc53758a9ad6245637300c7142\"/>\n"
//				+ "                <Token id=\"00115388f320a56dd46c38ddd7866794c6e87d3d5d8b5ca0f94643e4554cfcd8\"/>\n"
				+ "            </Tokens>\n"
				+ "        </Resp>\n"
				+ "    </ResDetails>\n"
				+ "</ns2:RespUpdateToken>";
//		String cleanedXmlData = Body.replace("\n", "");
//		System.out.println(cleanedXmlData);
		Response res = given().body(Body).when().post(
				"https://10.20.39.98:7001/retail/tokennpci/dashboard/api/token/RespUpdateToken/2.0/urn:txnid::{{retailTransferID}}");
				
	}
}
