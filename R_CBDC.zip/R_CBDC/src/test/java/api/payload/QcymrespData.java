package api.payload;

import api.test.CreateIssuance;

public class QcymrespData {
//	public static String txnId=CreateIssuance.Data4;
	 public String getXmlPayload() {
	        String txnId = CreateIssuance.Data4; 
	        String txnRefNo=" ";
	        System.out.println(txnId);// Assuming Data4 is a static variable accessible from CreateIssuance class
	        return "<ResToken xmlns:token=\"http://npci.org/token/schema/\">\n" +
	                "    <Head ver=\"1.0\" timestamp=\"2022-04-11T08:19:41.443Z\"/>\n" +
	                "    <ResDetails type=\"Debit\">\n" +
	                "        <Resp reqMsgId=\"cb36a5e9-4239-4a20-908b-3605b9a21bce\" result=\"SUCCESS\" errCode=\"000\" msg=\"RESTKN\"/>\n" +
	                "        <Details>\n" +
	                "            <Detail name=\"txnId\" value=\"" + txnId + "\"/>\n" +
	                "            <Detail name=\"orgId\" value=\" \"/>\n" +
	                "            <Detail name=\"memberID\" value=\"2224\"/>\n" +
	                "            <Detail name=\"accountLinkId\" value=\" \"/>\n" +
	                "            <Detail name=\"accountNumber\" value=\" \"/>\n" +
	                "            <Detail name=\"walletAddress\" value=\"0x7f3d6948ba19a062cc57d117a77685c2fbe4edfd\"/>\n" +
	                "            <Detail name=\"remarks\" value=\"maker-remarks-direct\"/>\n" +
	                "            <Detail name=\"type\" value=\"RETAIL\"/>\n" +
	                "            <Detail name=\"txnStatus\" value=\"SUCCESS\"/>\n" +
	                "        </Details>\n" +
	                "        <Transaction>\n" +
	                "            <Detail name=\"txnId\" value=\"" + txnRefNo + "\"/>\n" +
	                "            <Detail name=\"requestDate\" value=\"2022-05-04\"/>\n" +
	                "            <Detail name=\"memberID\" value=\"2224\"/>\n" +
	                "            <Detail name=\"accountNumber\" value=\"\"/>\n" +
	                "            <Detail name=\"walletAddress\" value=\"0x7f3d6948ba19a062cc57d117a77685c2fbe4edfd\"/>\n" +
	                "            <Detail name=\"amount\" value=\"50\"/>\n" +
	                "            <Detail name=\"timestamp\" value=\"2022-04-11T08:19:41.443Z\"/>\n" +
	                "            <Detail name=\"dateOfPayment\" value=\"2022-05-04\"/>\n" +
	                "            <Detail name=\"txnStatus\" value=\"SUCCESS\"/>\n" +
	                "            <Detail name=\"responseCode\" value=\"00\"/>\n" +
	                "        </Transaction>\n" +
	                "        <Amount value=\"50\" curr=\"INR\">\n" +
	                "            <Denominations>\n" +
	                "                <Denomination value=\"5\" count=\"10\"/>\n" +
	                "            </Denominations>\n" +
	                "        </Amount>\n" +
	                "    </ResDetails>\n" +
	                "</ResToken>";
	    }
	}
