package api.payload;

public class ApproveIndentData {
	private String status;
    private Indent indent;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Indent getIndent() {
		return indent;
	}
	public void setIndent(Indent indent) {
		this.indent = indent;
	}



public static class Indent {
    private String checkerRemark;

	public String getCheckerRemark() {
		return checkerRemark;
	}

	public void setCheckerRemark(String checkerRemark) {
		this.checkerRemark = checkerRemark;
	}
}
}
