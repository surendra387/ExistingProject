package api.payload;

import java.util.List;


public class SubmitDraftIssuanceData {

	
	private String makerRemarks;
	private String txnRefNo;
	private String status;
	public String getMakerRemarks() {
        return makerRemarks;
    }

    public void setMakerRemarks(String makerRemarks) {
        this.makerRemarks = makerRemarks;
    }

    public String getTxnRefNo() {
        return txnRefNo;
    }

    public void setTxnRefNo(String txnRefNo) {
        this.txnRefNo = txnRefNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    }
	
//	private int count;
//    private double denomination;
//
//    public int getCount() {
//        return count;
//    }
//
//    public void setCount(int count) {
//        this.count = count;
//    }
//
//    public double getDenomination() {
//        return denomination;
//    }
//
//    public void setDenomination(double denomination) {
//        this.denomination = denomination;
//    }
//
//
//public static class TokensRequest {
//    private double totalAmount;
//    private String makerRemarks;
//    private String txnRefNo;
//    private String status;
//    private List<TokensRequest> tokensRequested;
//
//    public double getTotalAmount() {
//        return totalAmount;
//    }
//
//    public void setTotalAmount(double totalAmount) {
//        this.totalAmount = totalAmount;
//    }
//
//    public String getMakerRemarks() {
//        return makerRemarks;
//    }
//
//    public void setMakerRemarks(String makerRemarks) {
//        this.makerRemarks = makerRemarks;
//    }
//
//    public String getTxnRefNo() {
//        return txnRefNo;
//    }
//
//    public void setTxnRefNo(String txnRefNo) {
//        this.txnRefNo = txnRefNo;
//    }
//
//    public String getStatus() {
//        return status;
//    }
//
//    public void setStatus(String status) {
//        this.status = status;
//    }
//
//    public List<TokensRequest> getTokensRequested() {
//        return tokensRequested;
//    }
//
//    public void setTokensRequested(List<TokensRequest> tokensRequested) {
//        this.tokensRequested = tokensRequested;
//    }
//}
//}
