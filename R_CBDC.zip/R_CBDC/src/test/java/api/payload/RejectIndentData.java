package api.payload;

public class RejectIndentData {
	private String status;
    private IndentInfo indent;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public IndentInfo getIndent() {
        return indent;
    }

    public void setIndent(IndentInfo indent) {
        this.indent = indent;
    }

public static class IndentInfo {
    private String checkerRemark;

    public String getCheckerRemark() {
        return checkerRemark;
    }

    public void setCheckerRemark(String checkerRemark) {
        this.checkerRemark = checkerRemark;
    }

    }

}
