package api.payload;

import java.util.List;

public class IssuanceData {
	private double totalAmount;
	private List<TokenRequest> tokensRequested;
	private String makerRemarks;
	private String txnRefNo;
	private String status;

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<TokenRequest> getTokensRequested() {
		return tokensRequested;
	}

	public void setTokensRequested(List<TokenRequest> tokensRequested) {
		this.tokensRequested = tokensRequested;
	}

	public String getMakerRemarks() {
		return makerRemarks;
	}

	public void setMakerRemarks(String makerRemarks) {
		this.makerRemarks = makerRemarks;
	}

	public String getTxnRefNo() {
		return txnRefNo;
	}

	public void setTxnRefNo(String txnRefNo) {
		this.txnRefNo = txnRefNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static class TokenRequest {
		private double denomination;
		private int count;

		public double getDenomination() {
			return denomination;
		}

		public void setDenomination(double denomination) {
			this.denomination = denomination;
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}
	}

}
