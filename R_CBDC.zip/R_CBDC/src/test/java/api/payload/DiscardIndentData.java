package api.payload;

public class DiscardIndentData {
private String status;
private String checkerRemark;
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getCheckerRemark() {
	return checkerRemark;
}
public void setCheckerRemark(String checkerRemark) {
	this.checkerRemark = checkerRemark;
}

}
