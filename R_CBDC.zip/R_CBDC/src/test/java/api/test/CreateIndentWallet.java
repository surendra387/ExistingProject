package api.test;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.WalletEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIndentWallet {
	@Test(priority = 1)
	public void createIndentWallet() {
		Response res = WalletEndpoints.createRBIWallet();
		String Body = res.getBody().asString();
	String response=res.jsonPath().getString("success");
	if(response.equalsIgnoreCase("true"))
	{
		System.out.println("####### RBI Wallet Created Successfully #######");
	}
	else 
	{
		System.out.println("####### RBI Wallet Creation  Failed #######");
	}
        //System.out.println(Body);
		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);
		
		// Validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 2)
	public void getIndentWallet() {
		Response res = WalletEndpoints.getCreateRBIWallet();
		String Body = res.getBody().asString();
		
		
		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);
		
		// Validate response status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Invalid status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}
}
