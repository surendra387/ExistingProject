package api.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import api.endpoints.IndentEndpoints;
import api.payload.ApproveIndentData;
import api.payload.IndentData;
import api.payload.IndentData.Indent;
import api.payload.IndentData.TokenToCreate;
import api.payload.RejectIndentData;
import api.payload.RejectIndentData.IndentInfo;
import api.payload.submitDraftIndentData;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreteIndent {
	IndentData requestBody;
	ApproveIndentData ApproveIndentBody;
	UpdateDraftIndentData updateDraftBody;
	submitDraftIndentData submitDraftBody;

	public static String Data1;
	public static String Data2;

	@BeforeMethod
	public void setUp() {
		Random r = new Random();
		int count = r.nextInt(50000) + 1;
//		System.out.println(count);
		List<Double> denominations = List.of(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0);
		Double randomDenominations = denominations.get(r.nextInt(denominations.size()));
//		System.out.println(randomDenominations);
		Double totalAmount = count * randomDenominations;
//		System.out.println(totalAmount);
		requestBody = new IndentData();
		requestBody.setStatus("Draft");
		Indent indent = new Indent();
		indent.setTotalAmount(totalAmount);
		indent.setMakerRemarks("maker remarks");
		indent.setTokenType("RETAIL");
		indent.setMaxCount(0);
//		indent.setExpirationTimestamp("");

		List<TokenToCreate> tokensToCreateList = new ArrayList<>();
		TokenToCreate token = new TokenToCreate();
		token.setCount(count);
		token.setDenomination(randomDenominations);
		tokensToCreateList.add(token);

		indent.setTokensToCreate(tokensToCreateList);
		requestBody.setIndent(indent);

	
	}
/*
 * This method is used to create draft indent.
 */
	@Test(priority = 1,enabled = true)
	public void draftIndent() {

		Response res = IndentEndpoints.createDraftIndent(requestBody);
		String Body = res.getBody().asString();
		 String response = res.jsonPath().getString("success");
		    
		    
		JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		Data1 = res.jsonPath().getString("data");
		System.out.println("Create Draft Indent id is :" + Data1);
		
		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}
	
/*
 * This method is used to update existing draft indent.
 */
	
	@Test(priority = 2,enabled = true)
	public void updateDraftIndent() {
		Response res= IndentEndpoints.updateDraftIndent(requestBody);
		String Body = res.getBody().asString();
		    		
		JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		
		Data1 = res.jsonPath().getString("data");
		System.out.println("Update Draft Indent id is :" + Data1);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	

	@Test(priority = 3,enabled = true)
	public static void submitDraftIndent() {
		submitDraftIndentData submitDraftBody = new submitDraftIndentData();

		submitDraftBody.setStatus("Create");
		api.payload.submitDraftIndentData.Indent indent1 = new api.payload.submitDraftIndentData.Indent();
		indent1.setMakerRemarks("maker remarks 12");
		submitDraftBody.setIndent(indent1);

		Response res = IndentEndpoints.submitDraftIndent(submitDraftBody);
		String Body = res.getBody().asString();

		JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		
		Data1 = res.jsonPath().getString("data");
		System.out.println("Submit Draft Indent id is :" + Data1);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 4,enabled = false)
	public void discardIndent() throws InterruptedException {
		Thread.sleep(3000);
		api.payload.DiscardIndentData discardIndentBody = new api.payload.DiscardIndentData();
		discardIndentBody.setStatus("Discard");
		discardIndentBody.setCheckerRemark("qwert");

		Response res = IndentEndpoints.discardIndent(discardIndentBody);
        
		String Body=res.getBody().asString();
		
	    JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		
		Data1 = res.jsonPath().getString("data");
		System.out.println("Discard Indent id is :" + Data1);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 5,enabled = true)
	public void createIndent() {
		requestBody.setStatus("CREATE");
		Response res = IndentEndpoints.createDraftIndent(requestBody);
		String Body = res.getBody().asString();
	
		JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		
		Data2 = res.jsonPath().getString("data");
		System.out.println("Create Indent id is :" + Data2);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

	}

	@Test(priority = 6,enabled = true,dependsOnMethods = {"createIndent"})
	public void approveIndent() throws InterruptedException  {
	Thread.sleep(5000);
		
		ApproveIndentBody = new ApproveIndentData();
		ApproveIndentBody.setStatus("APPROVE");

		api.payload.ApproveIndentData.Indent indent = new api.payload.ApproveIndentData.Indent();
		indent.setCheckerRemark("checkerRemark123");
		ApproveIndentBody.setIndent(indent);
		Response res = IndentEndpoints.approveIndent(ApproveIndentBody);
		
		String Body=res.getBody().asString();
		
		JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		
		String Data3 = res.jsonPath().getString("data");
		System.out.println("Approve Indent id is :" + Data3);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	

	@Test(priority = 7,enabled = false)
	public void rejectIndent() {
		
		RejectIndentData rejectIndentBody = new RejectIndentData();
		rejectIndentBody.setStatus("Reject");
		IndentInfo indent = new IndentInfo();
		indent.setCheckerRemark("Rejected Indent!");
		rejectIndentBody.setIndent(indent);

		Response res = IndentEndpoints.rejectIndent(rejectIndentBody);
		
		String Body=res.getBody().asString();
		
		JsonPath jp=new JsonPath(Body);
		System.out.println(jp.prettify());
		
		String Data = res.jsonPath().getString("data");
		System.out.println("Reject Indent Id is :" + Data);
		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	
	
}
