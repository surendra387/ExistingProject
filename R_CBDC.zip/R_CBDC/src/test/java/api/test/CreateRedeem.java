package api.test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import api.endpoints.RedeemEndpoints;
import api.payload.ApproveRedeemData;
import api.payload.RedeemData;
import api.payload.RedeemData.Token;
import io.restassured.response.Response;

public class CreateRedeem {

	RedeemData redeemData;
	ApproveRedeemData approveRedeemData;
	
	@BeforeMethod
	public void setUp() {
		Random r = new Random();
		int count = r.nextInt(5000) + 1;
//		System.out.println(count);
//		List<Double> denominations = List.of(0.5, 1.00, 5.00, 10.00, 50.00, 100.00, 200.00, 500.00);
		List<Double> denominations = List.of(500.00);
		Double randomDenominations = denominations.get(r.nextInt(denominations.size()));
//		System.out.println(randomDenominations);
		Double totalAmount = count * randomDenominations;
//		System.out.println(totalAmount);
		
		RedeemData redeemData =new RedeemData();
		
//        redeemData.setTotalAmount(totalAmount);
//        System.out.println(redeemData.getTotalAmount());
        
        List<Token> tokensRequested=new ArrayList<>();
        Token tokens=new Token();
        tokens.setCount(count);
        tokens.setDenomination(randomDenominations);
        tokensRequested.add(tokens);
        redeemData.setMakerRemarks("Test Remark");
		
		redeemData.setTxnRefNo("TXN-001");
		redeemData.setStatus("Create");
	}
	@Test(priority = 1)
	public void createRedeem() {
		Response res = RedeemEndpoints.createRedeem(redeemData);
		String Body=res.getBody().asString();
		System.out.println(Body);
		
		int statusCode=res.getStatusCode();
		Assert.assertEquals(statusCode, 200,"Invalid status code");
	}
	
}
