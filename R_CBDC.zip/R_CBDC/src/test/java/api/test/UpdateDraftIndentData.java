package api.test;

import java.util.List;

import api.payload.IndentData.TokenToCreate;

public class UpdateDraftIndentData {
	private  String status;
	   private  Indent indent;

	public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Indent getIndent() {
			return indent;
		}

		public void setIndent(Indent indent) {
			this.indent = indent;
		}

	public static class Indent {
	    public  double totalAmount;
	    private String makerRemarks;
	    private String tokenType;
	    private int maxCount;
	    private String expirationTimestamp;
	    private List<TokenToCreate> tokensToCreate;
		public double getTotalAmount() {
			return totalAmount;
		}
		public void setTotalAmount(double totalAmount) {
			this.totalAmount = totalAmount;
		}
		public String getMakerRemarks() {
			return makerRemarks;
		}
		public void setMakerRemarks(String makerRemarks) {
			this.makerRemarks = makerRemarks;
		}
		public String getTokenType() {
			return tokenType;
		}
		public void setTokenType(String tokenType) {
			this.tokenType = tokenType;
		}
		public int getMaxCount() {
			return maxCount;
		}
		public void setMaxCount(int maxCount) {
			this.maxCount = maxCount;
		}
		public String getExpirationTimestamp() {
			return expirationTimestamp;
		}
		public void setExpirationTimestamp(String expirationTimestamp) {
			this.expirationTimestamp = expirationTimestamp;
		}
		public List<TokenToCreate> getTokensToCreate() {
			return tokensToCreate;
		}
		public void setTokensToCreate(List<TokenToCreate> tokensToCreate) {
			this.tokensToCreate = tokensToCreate;
		}

	}

	public static class TokenToCreate {
	    private int count;
	    private Double denomination;
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
		public Double getDenomination() {
			return denomination;
		}
		public void setDenomination(Double denomination) {
			this.denomination = denomination;
		}
	     
	}
}