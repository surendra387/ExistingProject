package api.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import api.endpoints.IssuanceEndpoints;
import api.payload.ApproveIssuanceData;
import api.payload.DiscardIssuanceData;
import api.payload.IssuanceData;
import api.payload.IssuanceData.TokenRequest;
import api.payload.QcymrespData;
import api.payload.SubmitDraftIssuanceData;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIssuance {
	IssuanceData requestBody;
	SubmitDraftIssuanceData submitIssuanceBody;
//	TokensRequest requestData;
	public static String Data1;
	public static String Data2;
	public static String Data3;
	public static String Data4;
	QcymrespData qcymbody;
	@BeforeMethod
	
	public void setUp() {
		Random r = new Random();
		int count = r.nextInt(10000) + 1;
//		System.out.println(count);
//		List<Double> denominations = List.of(0.5, 1.00,2.00, 5.00, 10.00, 50.00, 100.00, 200.00, 500.00);
		List<Double> denominations = List.of(100.00);

		Double randomDenominations = denominations.get(r.nextInt(denominations.size()));
//		System.out.println(randomDenominations);
		Double totalAmount = count * randomDenominations;
//		System.out.println(totalAmount);

		requestBody = new IssuanceData();
		requestBody.setStatus("DRAFT");
		requestBody.setMakerRemarks("Test Remark");
		requestBody.setTotalAmount(totalAmount);
		requestBody.setTxnRefNo("TXN-001");
		List<TokenRequest> tokensRequested = new ArrayList<IssuanceData.TokenRequest>();
		TokenRequest tokens = new TokenRequest();
		tokens.setCount(count);
		tokens.setDenomination(randomDenominations);
		tokensRequested.add(tokens);
		requestBody.setTokensRequested(tokensRequested);
//		System.out.println("totalAount :" + requestBody.getTotalAmount());

	}


	@Test(priority = 1)
	public void createDraftIssuance() {
		Response res = IssuanceEndpoints.draftIssuance(requestBody);
		String Body = res.getBody().asString();

		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
		System.out.println(formatedBody);

		Data1 = res.jsonPath().getString("data");
		System.out.println("create Draft Issuance Id is :" + Data1);

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}

	@Test(priority = 2)
	public void createIssuance() {
		requestBody.setStatus("CREATE");
		Response res = IssuanceEndpoints.createIssuance(requestBody);
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
		System.out.println(formatedBody);
		Data2 = res.jsonPath().getString("data");
		System.out.println("createIssuance Id is:" + Data2);

//		validate response the status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Incorrect status code");
//		validate the response status line

		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}

	@Test(priority = 3)
	public void updateDratIssuance() {
		Response res = IssuanceEndpoints.updateDraftIssuance(requestBody);
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedJson = jp.prettify();
		System.out.println(formatedJson);
		Data1 = res.jsonPath().getString("data");
		System.out.println("updateDratIssuance Id is :" + Data1);

		// Validate response time
		long responseTime = res.getTime();
		Assert.assertTrue(responseTime < 1500, "Response time is lesser than 1500  milliseconds");
	}

	@Test(priority = 4,enabled = true)
	public void submitDraftIssuance() {
		submitIssuanceBody = new SubmitDraftIssuanceData();
		submitIssuanceBody.setMakerRemarks("maker-remarks-direct");
		submitIssuanceBody.setStatus("Create");
		submitIssuanceBody.setTxnRefNo("");
	   
	  
//		requestBody.setStatus("Create");
	  
	   
		Response res = IssuanceEndpoints.submitDraftIssuance(submitIssuanceBody);

		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
		System.out.println(formatedBody);
		Data1 = res.jsonPath().getString("data");
		System.out.println("submitDraftIssuance Id is:" + Data1);

//		validate response the status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Incorrect status code");
//		validate the response status line

		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
//	@Test(priority = 5,enabled = false)
	public void discardIssunace() {
		DiscardIssuanceData discardIssuanceBody=new DiscardIssuanceData();
		discardIssuanceBody.setMakerRemarks("maker-remarks-direct");
		discardIssuanceBody.setStatus("Discard");
		discardIssuanceBody.setTxnRefNo("");
		Response res = IssuanceEndpoints.discardIssuance(discardIssuanceBody);
		
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
		System.out.println(formatedBody);
		Data1 = res.jsonPath().getString("data");
		System.out.println("Discard DraftIssuance Id is:" + Data1);

//		validate response the status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Incorrect status code");
//		validate the response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Incorrect status line");
		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
	@Test(priority = 6)
	public void checkerApproveIssuance() throws InterruptedException
	{
		Thread.sleep(3000);
		ApproveIssuanceData approveIssuanceBody=new ApproveIssuanceData();
		approveIssuanceBody.setMakerRemarks("maker-remarks-direct");
		approveIssuanceBody.setTxnRefNo("");
		approveIssuanceBody.setStatus("CHECK_APPROVE");
		
	Response res = IssuanceEndpoints.approveIssuance(approveIssuanceBody);
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
		System.out.println(formatedBody);
	     Data3 = res.jsonPath().getString("data");
		System.out.println(" Approve Issuance Id is:" + Data3);

//		validate response the status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Incorrect status code");
//		validate the response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Incorrect status line");
		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
//	@Test(priority = 7)
//	public void rbiIssuanceApprover()
//	{
//		RbiIssuanceApproveData rbiIssuanceApproveData=new RbiIssuanceApproveData();
//		rbiIssuanceApproveData.setMakerRemarks("regulator-remarks-direct");
//		rbiIssuanceApproveData.setTxnRefNo("");
//		rbiIssuanceApproveData.setStatus("APPROVE");
//		
//		Response res = IssuanceEndpoints.RBIIssuanceApprover(rbiIssuanceApproveData);
//		
//		String Body = res.getBody().asString();
//		JsonPath jp = new JsonPath(Body);
//		String formatedBody = jp.prettify();
//		System.out.println(formatedBody);
//	     Data4 = res.jsonPath().getString("data");
//		System.out.println(" RBI Approve Issuance Id is:" + Data4);
//
////		validate response the status code
//		int statusCode = res.getStatusCode();
//		Assert.assertEquals(statusCode, 200, "Incorrect status code");
////		validate the response status line
//		String statusLine = res.getStatusLine();
//		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Incorrect status line");
//		// Validate the response content type
//		String loginContentType = res.getContentType();
//		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
//	}
////	@Test(priority = 8)
//	public void qcymRespTokenDebit()
//	{
//		 QcymrespData qcymrespData = new QcymrespData();
//	        String xmlPayload = qcymrespData.getXmlPayload();
//	        System.out.println("Response: " +xmlPayload .toString());
//	Response res = IssuanceEndpoints.QCYMrespTokendebit(xmlPayload);
//	String body = res.getBody().asString();
//	System.out.println(body);
////	validate response the status code
//	int statusCode = res.getStatusCode();
//	Assert.assertEquals(statusCode, 200, "Incorrect status code");
//	
//	}
	

}
