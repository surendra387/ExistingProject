package api.test;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.Login;
import api.payload.LoginUserData;
import api.utilities.propertyFileUtility;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class SBI_LoginApi {
	public static String id;
	public static String enc_N;
	public static String enc_K;
	public static String encUsername;
	public static String encPassword;
    public static String Bearer_Token_Sbi;
	LoginUserData requestBody;
	propertyFileUtility pUtil = new propertyFileUtility();

	@Test(priority = 1)
	public void getSession() {

		Response res = Login.gettSessionBySbi();
		String Body = res.getBody().asString();
		
		id = res.jsonPath().getString("data.id");
		enc_N = res.jsonPath().getString("data.enc_i");
		enc_K = res.jsonPath().getString("data.enc_k");
		
		JsonPath jp = new JsonPath(Body);
//		System.out.println(jp.prettify());
		
   

		// Validate the response status code
		int loginStatusCode = res.getStatusCode();
		Assert.assertEquals(loginStatusCode, 200, "Incorrect status code");

		// Validate the response status line
		String loginStatusLine = res.getStatusLine();
		Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
        
	}    
	
	@Test(priority = 2)
	public void encryptAndDecrypt()
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IOException {

		String USERNAME = pUtil.readDataFromPropertyFile("sbi_username");
		String PASSWORD = pUtil.readDataFromPropertyFile("sbi_password");

//		System.out.println(USERNAME);
//		System.out.println(PASSWORD);
		
		byte[] keyBytes = hexStringToByteArray(enc_K);
		byte[] ivBytes = hexStringToByteArray(enc_N);

		SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
		byte[] encryptedUsername = encrypt(USERNAME, secretKey, ivBytes);
		byte[] encryptedPassword = encrypt(PASSWORD, secretKey, ivBytes);

		encUsername = Base64.getEncoder().encodeToString(encryptedUsername);
		encPassword = Base64.getEncoder().encodeToString(encryptedPassword);

//		System.out.println("Encrypted Username: " + encUsername);
//		System.out.println("Encrypted Password: " + encPassword);

		String decryptedUsername = decrypt(Base64.getDecoder().decode(encUsername), secretKey, ivBytes);
		String decryptedPassword = decrypt(Base64.getDecoder().decode(encPassword), secretKey, ivBytes);

//		System.out.println("Decrypted Username: " + decryptedUsername);
//		System.out.println("Decrypted Password: " + decryptedPassword);

		Assert.assertEquals(USERNAME, decryptedUsername);
		Assert.assertEquals(PASSWORD, decryptedPassword);
	}

	public byte[] encrypt(String data, SecretKey secretKey, byte[] ivBytes)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(ivBytes));

		return cipher.doFinal(data.getBytes());
	}

	public String decrypt(byte[] encryptedData, SecretKey secretKey, byte[] ivBytes)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(ivBytes));

		byte[] decryptedBytes = cipher.doFinal(encryptedData);

		return new String(decryptedBytes);
	}

	public static byte[] hexStringToByteArray(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
		}
		return data;
	}

	@Test(priority = 3)
	public void userLogin() throws InterruptedException {
//		Thread.sleep(3000);
		

		requestBody = new LoginUserData();

		requestBody.setId(id);
		requestBody.setUsername(encUsername);
		requestBody.setPassword(encPassword);
		
//        System.out.println("request body is:"+requestBody);
        
		Response res=Login.loginUserBySbi(requestBody);
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
//		System.out.println(formatedBody);
		
		Bearer_Token_Sbi=res.jsonPath().getString("data.token");
	   	    
        //validate the status code in response body		
		int statusCode=res.getStatusCode();
		Assert.assertEquals(statusCode,200,"Invalid status code" );
		//validate the status line in response body	
		String statusLine=res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK","Incorrect status line");
		//validate the content type in response body	
		String contentType=res.getContentType();
		Assert.assertEquals(contentType, "application/json","Invalid content Type");
//		
	}

}
