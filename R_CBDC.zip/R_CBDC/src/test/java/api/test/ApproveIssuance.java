package api.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.RBIIssuanceApproverEndpoints;
import api.payload.RbiIssuanceApproveData;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ApproveIssuance {
	
	public static String Data4;

	@Test(priority = 1)
	public void rbiIssuanceApprover()
	{
		RbiIssuanceApproveData rbiIssuanceApproveData=new RbiIssuanceApproveData();
		rbiIssuanceApproveData.setMakerRemarks("regulator-remarks-direct");
		rbiIssuanceApproveData.setTxnRefNo("");
		rbiIssuanceApproveData.setStatus("APPROVE");
		
		Response res = RBIIssuanceApproverEndpoints.RBIIssuanceApprover(rbiIssuanceApproveData);
		
		String Body = res.getBody().asString();
		JsonPath jp = new JsonPath(Body);
		String formatedBody = jp.prettify();
		System.out.println(formatedBody);
	     Data4 = res.jsonPath().getString("data");
		System.out.println(" RBI Approve Issuance Id is:" + Data4);

//		validate response the status code
		int statusCode = res.getStatusCode();
		Assert.assertEquals(statusCode, 200, "Incorrect status code");
//		validate the response status line
		String statusLine = res.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Incorrect status line");
		// Validate the response content type
		String loginContentType = res.getContentType();
		Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");
	}
//	@Test(priority = 8)
//	public void qcymRespTokenDebit()
//	{
//		 QcymrespData qcymrespData = new QcymrespData();
//	        String xmlPayload = qcymrespData.getXmlPayload();
//	        System.out.println("Response: " +xmlPayload .toString());
//	Response res = IssuanceEndpoints.QCYMrespTokendebit(xmlPayload);
//	String body = res.getBody().asString();
//	System.out.println(body);
////	validate response the status code
//	int statusCode = res.getStatusCode();
//	Assert.assertEquals(statusCode, 200, "Incorrect status code");
//	
//	}

}
