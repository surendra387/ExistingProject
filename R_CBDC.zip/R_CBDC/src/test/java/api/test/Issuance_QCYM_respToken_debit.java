package api.test;
import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import io.restassured.response.Response;
public class Issuance_QCYM_respToken_debit extends RBI_LoginApi {
@Test
public static void qcymResToken() throws SAXException, IOException, ParserConfigurationException, TransformerException {
	String txnId = ApproveIssuance.Data4;
	System.out.println(txnId);
//	 String ApproveIssuance Data4;
//	String Bearer_Token_bank="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxfSwicGVybWlzc2lvbnMiOlsiVklFV19ST0xFUyIsIlZJRVdfVkFVTFQiLCJDUkVBVEVfVVNFUiIsIkFETUlOIiwiVklFV19SRURFRU1fUkVRVUVTVCIsIlZJRVdfSURfREFTSEJPQVJEIiwiVklFV19VU0VSIiwiQ1JFQVRFX1ZBVUxUIiwiVklFV19JTkRFTlQiLCJWSUVXX0lOREVOVF9EUkFGVCIsIlZJRVdfUkVDQUxMX1JFUVVFU1QiLCJWSUVXX0JBTEFOQ0UiLCJWSUVXX0lTU1VBTkNFX1JFUVVFU1QiXSwidHdvZmFfdmVyaWZpZWQiOmZhbHNlLCJleHAiOjE3MTEyODY1NzYsInN1YiI6IkxPR0lOIn0.T0Ngsb3uiR4Pmd54U9heQ1NF_Gp8EtglUKAlwc0JL-pIfzgneVCP5lmaJ4guYL7w2upjB9jVZuq0kUsnS7RVcbyFr66kVmr3loJ4ZdoCvcmXSWa3Tn3D-LVCIbLc2WbCL-0cq6_7UKUvO93WBoMUyOeibFGvZXHBKmqq2alJBjIpoqhxu2CCv43mSsoiLB1mIKpAmO6TO8B0SrAsjTcmxriFYtW7otTaJKgHc_yDIV7l1ekBgRyOn9N0QdlqcKzJ5SbEQdC-zJunfkOAeaLe9a2mdrwHxcCG6TWyVT8XbFSCPGBS434MPup977UFB4z_cUvdraKGcgRx5pVE_i6r3g";
//		String  Data4 = "R-2024-IS--ec8e7275-b093"; 

	String Body = "<ResToken xmlns:token=\"http://npci.org/token/schema/\">\n"
	        + "    <Head ver=\"1.0\" timestamp=\"2022-04-11T08:19:41.443Z\"/>\n"
	        + "    <ResDetails type=\"Debit\">\n"
	        + "        <Resp reqMsgId=\"cb36a5e9-4239-4a20-908b-3605b9a21bce\" result=\"SUCCESS\" errCode=\"000\" msg=\"RESTKN\"/>\n"
	        + "        <Details>\n"
	        + "            <Detail name=\"txnId\" value=\"" + txnId + "\"/>\n" 
	        + "            <Detail name=\"orgId\" value=\" \"/>\n"
	        + "            <Detail name=\"memberID\" value=\"2224\"/>\n"
	        + "            <Detail name=\"accountLinkId\" value=\" \"/>\n"
	        + "            <Detail name=\"accountNumber\" value=\" \"/>\n"
	        + "            <Detail name=\"walletAddress\" value=\"0x7f3d6948ba19a062cc57d117a77685c2fbe4edfd\"/>\n"
	        + "            <Detail name=\"remarks\" value=\"maker-remarks-direct\"/>\n"
	        + "            <Detail name=\"type\" value=\"RETAIL\"/>\n"
	        + "            <Detail name=\"txnStatus\" value=\"SUCCESS\"/>\n"
	        + "        </Details>\n"
	        + "        <Transaction>\n"
	        + "            <Detail name=\"txnId\" value=\"-\"/>\n"
	        + "            <Detail name=\"requestDate\" value=\"2022-05-04\"/>\n"
	        + "            <Detail name=\"memberID\" value=\"2224\"/>\n"
	        + "            <Detail name=\"accountNumber\" value=\"\"/>\n"
	        + "            <Detail name=\"walletAddress\" value=\"0x7f3d6948ba19a062cc57d117a77685c2fbe4edfd\"/>\n"
	        + "            <Detail name=\"amount\" value=\"50\"/>\n"
	        + "            <Detail name=\"timestamp\" value=\"2022-04-11T08:19:41.443Z\"/>\n"
	        + "            <Detail name=\"dateOfPayment\" value=\"2022-05-04\"/>\n"
	        + "            <Detail name=\"txnStatus\" value=\"SUCCESS\"/>\n"
	        + "            <Detail name=\"responseCode\" value=\"00\"/>\n"
	        + "        </Transaction>\n"
	        + "        <Amount value=\"50\" curr=\"INR\">\n"
	        + "            <Denominations>\n"
	        + "                <Denomination value=\"5\" count=\"10\"/>\n"
	        + "            </Denominations>\n"
	        + "        </Amount>\n"
	        + "    </ResDetails>\n"
	        + "</ResToken>";

	Response res=given()
	.headers("Authorization", "Bearer "+Bearer_Token_Rbi )
	.body(Body)
	.when()
	.post("http://localhost:9002/rrb/api/retail-token-system/v1/respToken");
    String body=res.getBody().asString();
//	System.out.println(body);
	
	
	// Parse XML string into Document
    Document document = javax.xml.parsers.DocumentBuilderFactory.newInstance()
                                    .newDocumentBuilder()
                                    .parse(new InputSource(new StringReader(body)));

    // Create transformer
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

    // Format XML
    StringWriter stringWriter = new StringWriter();
    transformer.transform(new DOMSource(document), new StreamResult(stringWriter));
    String formattedXml = stringWriter.toString();

    // Print formatted XML
    System.out.println(formattedXml);
	
}
}
