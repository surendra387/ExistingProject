package api.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import api.endpoints.SBIWalletEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIssuanceWallet {
@Test(priority = 1)
public void createIssuanceWallet() {
	Response res=SBIWalletEndpoints.createIssunaceWallet();
	
	String Body = res.getBody().asString();
	JsonPath jp = new JsonPath(Body);
	String formatedJson = jp.prettify();
	System.out.println(formatedJson);
	
	// Validate response status code
	int statusCode = res.getStatusCode();
	Assert.assertEquals(statusCode, 200, "Invalid status code");

	// Validate the response status line
	String loginStatusLine = res.getStatusLine();
	Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	// Validate the response content type
	String loginContentType = res.getContentType();
	Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

}

@Test(priority = 2)
public void getIndentWallet() {
	Response res = SBIWalletEndpoints.getcreateIssunaceWallet();
	
	String Body = res.getBody().asString();
	JsonPath jp = new JsonPath(Body);
	String formatedJson = jp.prettify();
	System.out.println(formatedJson);
	
	// Validate response status code
	int statusCode = res.getStatusCode();
	Assert.assertEquals(statusCode, 200, "Invalid status code");

	// Validate the response status line
	String loginStatusLine = res.getStatusLine();
	Assert.assertEquals(loginStatusLine, "HTTP/1.1 200 OK", "Incorrect status line");

	// Validate the response content type
	String loginContentType = res.getContentType();
	Assert.assertEquals(loginContentType, "application/json", "Incorrect content type");

}
}
