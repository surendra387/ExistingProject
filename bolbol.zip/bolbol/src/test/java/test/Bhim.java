package test;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.net.URL;
import java.net.MalformedURLException;

public class Bhim {
    public static void main(String[] args) {
        // Set the Desired Capabilities
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "13"); // Update based on your device version
        caps.setCapability("deviceName", "Android Emulator"); // Update based on your device or emulator name
        caps.setCapability("automationName", "UiAutomator2");
        caps.setCapability("appPackage", "in.org.npci.upiapp"); // BHIM app package
        caps.setCapability("appActivity", "in.org.npci.upiapp.HomeScreenActivity"); // BHIM app main activity
        caps.setCapability("noReset", true); // To retain app state between sessions

        // Initialize the driver
        try {
            AndroidDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), caps);

            // Example interactions with the BHIM app

            // Wait for the BHIM home screen to load (you can adjust the wait time as needed)
            Thread.sleep(5000);

            // Click on the "Send" button using the correct locator
            WebElement sendButton = driver.findElement(By.id("in.org.npci.upiapp:id/sendButton"));
            sendButton.click();

            // Find UPI input field and send UPI ID
            WebElement upiInput = driver.findElement(By.id("in.org.npci.upiapp:id/upiInputField"));
            upiInput.sendKeys("9876543210@upi");

            // Perform further actions like sending money, checking balance, etc.

            // Close the session
            driver.quit();

        } catch (MalformedURLException e) {
            System.out.println("Invalid Appium server URL.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
