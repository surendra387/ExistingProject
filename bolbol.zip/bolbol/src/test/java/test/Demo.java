package test;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class Demo {
@Test
public void tes1() {
	System.out.println("test1");
}
@Test
public void test2() {
	System.out.println("test2");
}
@Test()
public void test3() {
	System.out.println("test3");
}
@Test
public void test4() {
	System.out.println("teast4");
}

}
