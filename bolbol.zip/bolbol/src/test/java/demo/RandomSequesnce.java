package demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RandomSequesnce {
public static void main(String[] args) {
    List<Integer> numbers = new ArrayList<>();
    for (int i = 0; i <= 50; i++) {
        numbers.add(i);

    }
    
    Collections.shuffle(numbers);
    
    for (int number : numbers) {
        System.out.println(number);
     

    }

}
}
