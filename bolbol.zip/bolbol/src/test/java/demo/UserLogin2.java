package demo;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
public class UserLogin2 {

//	    public static void main(String[] args) {
//	        // Assuming you have the values for id, encUsername, and encPassword
//	        String id = "XLrGAD6F";
//	        String encUsername = "AHYO6EzG5eUfBK7REiHEmw";
//	        String encPassword = "byweWOwRAmmx6bJ8qaOlEA";
//
//	        	        String jsonPayload = "{\n" +
//	                "    \"id\": \"" + id + "\",\n" +
//	                "    \"username\": \"" + encUsername + "\",\n" +
//	                "    \"password\": \"" + encPassword + "\"\n" +
//	                "}";
//
//	        // Constructing the complete request body
//	        String requestBody = "{\n" +
//	                "    \"mode\": \"raw\",\n" +
//	                "    \"raw\": " + jsonPayload + ",\n" +
//	                "    \"options\": {\n" +
//	                "        \"raw\": {\n" +
//	                "            \"language\": \"json\"\n" +
//	                "        }\n" +
//	                "    }\n" +
//	                "}";
//
//	        // Sending the request using RestAssured
//	        Response response = RestAssured.given()
////	                .contentType(ContentType.JSON) // Set content type as JSON
//	                .body(requestBody) // Set the complete request body
//	                .when()
//	                .post("http://localhost:9002/rrb/api/retail-token-system/v1/auth/login"); // Replace with your actual API endpoint URL
//
//	        // Printing the response
//	        System.out.println("Response body: " + response.getBody().asString());
//	        System.out.println("Status code: " + response.getStatusCode());
//	    }
	

	
	    public static void main(String[] args) {
	        // Set the base URI of your API
	        

	        // Define the JSON payload
	        String id = "U8jMgUQR";
	        String encUsername = "ifj9015fcuYWWaDl2eSMXw==";
	        String encPassword = "E4y3W2REh4RIhI6CeRbuSw==";

	        String jsonPayload = String.format("{\"id\":\"%s\",\"username\":\"%s\",\"password\":\"%s\"}", id, encUsername, encPassword);

	        // Send the request using RestAssured
	        RestAssured.given()
	                .contentType(ContentType.JSON) // Set the content type as JSON
	                .body(jsonPayload) // Set the JSON payload
	                .when()
	                .post("http://localhost:9002/rrb/api/retail-token-system/v1/auth/login") // Specify your API endpoint
	                .then().log().all();
	                
	    }
	}

	
	
