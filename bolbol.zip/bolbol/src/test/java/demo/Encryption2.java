package demo;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Encryption2 {
public 	String encodedUsername;
public String encodedPassword;
	@BeforeMethod
	public void encryptAndDecrypt() throws NoSuchPaddingException, NoSuchAlgorithmException,
			InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		// Provided key and initialization vector (IV) as hexadecimal strings
		String keyHex = "a5a2b1bdcc26a7b96a2f6d8ae23de22d57e474d3d70d68de795fe653c8797ae8";
		String ivHex = "cf383ff5841c14fa9069c0a2d6840d93";

		// Username and password to encrypt
		String username = "ADMIN";
		String password = "Test@12345";

		// Convert the key and IV from hexadecimal to bytes
		byte[] keyBytes = hexStringToByteArray(keyHex);
		byte[] ivBytes = hexStringToByteArray(ivHex);

		// Create a SecretKeySpec for the key
		SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");

		// Encrypt the username and password
		byte[] encryptedUsername = encrypt(username, secretKey, ivBytes);
		byte[] encryptedPassword = encrypt(password, secretKey, ivBytes);

		// Encode the encrypted bytes in Base64
		 encodedUsername = Base64.getEncoder().encodeToString(encryptedUsername);
		 encodedPassword = Base64.getEncoder().encodeToString(encryptedPassword);

		// Print the results in the desired format
		System.out.println("Encrypted Username: " + encodedUsername);
		System.out.println("Encrypted Password: " + encodedPassword);

		// Decrypt the username and password
		String decryptedUsername = decrypt(Base64.getDecoder().decode(encodedUsername), secretKey, ivBytes);
		String decryptedPassword = decrypt(Base64.getDecoder().decode(encodedPassword), secretKey, ivBytes);

		// Print the decrypted results
		System.out.println("Decrypted Username: " + decryptedUsername);
		System.out.println("Decrypted Password: " + decryptedPassword);

		// Assert to check if the decryption is successful
		assertEquals(username, decryptedUsername);
		assertEquals(password, decryptedPassword);
	}

	public byte[] encrypt(String data, SecretKey secretKey, byte[] ivBytes)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		// Initialize the Cipher in encryption mode with CBC and PKCS5Padding
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(ivBytes));

		// Encrypt the data
		return cipher.doFinal(data.getBytes());
	}

	public String decrypt(byte[] encryptedData, SecretKey secretKey, byte[] ivBytes)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		// Initialize the Cipher in decryption mode with CBC and PKCS5Padding
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(ivBytes));

		// Decrypt the data
		byte[] decryptedBytes = cipher.doFinal(encryptedData);

		return new String(decryptedBytes);
	}

	public static byte[] hexStringToByteArray(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
		}
		return data;
	}
	
	@Test
	public void login() {
		HashMap<String,Object> body=new HashMap<String,Object>();
		body.put("id", "tRRYDVNT");
		body.put("username",encodedUsername);
		body.put("password",encodedPassword);
		given()
		.body(body)
		.when()
		.post("http://localhost:9002/rrb/api/retail-token-system/v1/auth/login")
		.then()
		.log().all();
	}
}
