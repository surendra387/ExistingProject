package saASDFGJ;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;


public class TZXHJ {
	WebDriver driver;
	@Test
	public void login() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);

//        WebDriver driver=new ChromeDriver();
		 
		driver.manage().window().maximize();
		System.out.println("Browser launched successfully");
		driver.get("https://www.flipkart.com");
	WebElement element = driver.findElement(By.xpath("//input[@class='Pke_EE']"));
	element.sendKeys("iphone14");
	element.submit();
	}
}
