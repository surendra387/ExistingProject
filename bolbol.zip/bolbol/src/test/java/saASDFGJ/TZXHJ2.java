package saASDFGJ;

import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class TZXHJ2 {
	WebDriver driver;

	@Test
	public void login() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);

//        WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		System.out.println("Browser launched successfully");
		driver.get("https://www.flipkart.com");
		
//		WebElement element = driver.findElement(By.xpath("//input[@class='Pke_EE']"));
//		element.sendKeys("iphone14");
//		element.submit();

//		char[] name= {'a','b'};
//		for(char n:name)
//		{
//			System.out.println(n);
//		}
//		
//	
//		int[] arr= {1,2,3,4,5,6,7,8,9,10};
		
//		for(int i=arr.length-1;i>=0;i--)
//		{
//			System.out.println(arr[i]);
//		}
		
		
		
//		for(int z:arr)
//		{
//			if()
//			{
//				System.out.println(z);
//			}
//		}
//		for (int i=1;i<arr.length;i++)
//		
//			if(arr[i]%2!=0) 
//				System.out.println(arr[i]);
//			else 
//				
//				System.out.println("asdfg");
				
//		
//		
//		for(int i:arr)
//		{
//			if(i%2==0)
//			{
//				System.out.println(i);
//			}
//		}
//	}

//		int a=5;
//		int b=6;
//		int c=a++ + ++b;
//		int d=--c + ++b;
//		int e=a++ + ++d - --d + c++;
		
//		 System.out.println(c);
//		 System.out.println(d);
//		 System.out.println(e);
		
//		int a=5;
//		int b=1;
//		
//		try {
//			int c=a/b;
//			System.out.println(c);
//		} catch (Exception e) {
//			// TODO: handle exception
//			System.out.println("+++FG++++");
//			System.out.println("asdfgh");
//		}
//		finally {
//			System.out.println("SURENDRA");
//			System.out.println("SURENDRA");
//		}
//		
		
	}
}
